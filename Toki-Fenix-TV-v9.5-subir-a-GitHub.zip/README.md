# Toki Lite Fénix TV v9.5 — Reproductor minimalista para Fire Stick

Extiende la versión v9.4 del catálogo AnimeAV1, con el mismo diseño Fénix aprobado. **No es una APK compilada.**

## Qué cambió en el reproductor

- Reproductor nativo **AndroidX Media3 / ExoPlayer** a pantalla completa: no renderiza la web como pantalla de reproducción.
- Controles propios inspirados en patrones de aplicaciones de TV (no copia de activos gráficos de Crunchyroll): fondo negro, paneles discretos con bordes, acento naranja al recibir foco.
- Panel superior: Volver, nombre del episodio y calidad real detectada mediante `Player.Listener.onVideoSizeChanged`.
- Panel inferior: línea de tiempo, avance/retroceso de 10 s, reproducir/pausar, **Audio**, **Subtítulos** a la izquierda y **Servidor N / Cambiar** a la derecha.
- Navegación por mando Fire Stick: direcciones, OK, Atrás y botón multimedia; controles se ocultan a los 4,2 s durante la reproducción y reaparecen al tocar una flecha.
- **Audio y subtítulos reales:** se enumeran únicamente las pistas que reporte Media3. Audio LAT/SUB/DUB en archivos separados se ofrecerá solo cuando el resolutor entregue sus URLs como fuentes adicionales.
- **Servidor:** lista de fuentes multimedia verificadas, si hay más de una. El selector **no inventa servidores**: con una única fuente muestra que no hay alternativas.
- Al cambiar de fuente se preserva, cuando sea posible, la posición de reproducción y se recrea Media3 con las cabeceras `Referer`/cookies de esa fuente (solo en sesiones normales del usuario).
- Se incluyeron los enlaces multimedia directos alternativos presentes explícitamente en el HTML del episodio como candidatos al selector. No se incluyen páginas HTML ni iframes.

## Pendientes conocidos

- Sin un flujo de vídeo real verificable de AnimeAV1/Toki, **no está demostrado que el reproductor nativo pueda iniciar un episodio**. La ficha de un episodio no equivale a su stream multimedia.
- No está implementada la clasificación confiable por LAT/SUB/DUB de enlaces que el proveedor publique como archivos separados; no se asignan idiomas por conjeturas.
- No se han ejecutado pruebas en un Fire Stick real. Las pruebas incluidas validan código independiente de Android y contratos estáticos de UI; **no son pruebas de integración Media3**.
- El proyecto **no implementa bypass de DRM, CAPTCHA, paywalls ni control de acceso**.
- La pantalla de catálogo usa HTML/JS **local** dentro de una WebView, pero el reproductor es una `Activity` Media3 nativa. Por eso esto no equivale a reescribir toda la aplicación en Compose/Android Views.

## Compilar APK

Se necesita Android SDK 35, JDK 17, Gradle 8.12 y acceso a Google Maven. Ejecutar:

```bash
gradle :app:assembleDebug
```

Alternativamente, usar `.github/workflows/android-apk.yml` en un repositorio propio habilitado para GitHub Actions.
La APK se genera en `app/build/outputs/apk/debug/app-debug.apk` y requiere instalación de depuración; la firma puede diferir de las betas previas.

## Pruebas ejecutables locales

```bash
node --check app/src/main/assets/tv.js
python tests/test_animeav1_ui.py
python tests/test_player_v9_5_contract.py
bash tests/run-parser-tests.sh
javac -d build/qualitytest app/src/main/java/com/tokilite/tv/VideoQualityLabel.java tests/VideoQualityLabelTest.java
java -cp build/qualitytest com.tokilite.tv.VideoQualityLabelTest
```
