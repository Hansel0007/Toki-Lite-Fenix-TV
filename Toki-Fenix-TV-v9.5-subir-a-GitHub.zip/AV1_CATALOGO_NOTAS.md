# Fuentes públicas verificadas para la integración

Fecha de consulta: 4 de noviembre de 2026.

- Inicio: https://animeav1.com/
- Catálogo: https://animeav1.com/catalogo
- Página 2: https://animeav1.com/catalogo?page=2
- Género Acción: https://animeav1.com/catalogo?genre=accion
- Ficha ejemplo: https://animeav1.com/media/one-piece
- Episodio ejemplo: https://animeav1.com/media/one-piece/1
- Términos: https://animeav1.com/pages/terminos-y-condiciones
- API de Media3 para calidad: https://developer.android.com/reference/androidx/media3/common/Player.Listener

No se ha probado un flujo de vídeo directo. Los proveedores de vídeo pueden imponer sus propias condiciones de acceso. La mera existencia de una opción HLS en la web no significa que el manifiesto sea accesible para un cliente externo.
