# v9.3 — Reconocimiento de fuentes multimedia .bin

## Evidencia
En una captura del navegador Android al reproducir un capítulo de Bleach, el menú contextual muestra un nombre de archivo con formato UUID y extensión `.bin`. **El nombre no demuestra que el recurso sea directamente reproducible**: podría ser un nombre sugerido de descarga, un binario con datos multimedia, un segmento, o un archivo de formato desconocido.

## Cambio realizado
- Acepta `https://.../*.bin` únicamente como **candidato** si aparece en un elemento de vídeo, un campo multimedia explícito o una solicitud observada durante la carga normal del episodio.
- Hace una comprobación limitada de bytes iniciales (GET con `Range: bytes=0-511`) y MIME del servidor; limita a cuatro candidatos por episodio y no sigue redirecciones.
- Identifica MP4, WebM, HLS y DASH por tipo o cabecera, rechazando HTML y binarios arbitrarios.
- Pasa el MIME verificado a Media3 si la URL tiene extensión no estándar, dejando intactos los controles del reproductor.
- No cambia cookies, el perfil, el diseño, no omite DRM, CAPTCHA ni controles de autorización; no se fabrican tokens.

## Límites
La captura **no permite conocer la URL real**, su MIME, las cabeceras, ni si usa MSE o DRM. El contenido puede provenir de un servidor externo. No hay verificación contra un capítulo real ni APK compilada en esta entrega.

## Pruebas realizadas
`sh tests/run-parser-tests.sh` — pasan pruebas de parser y clasificación de prefijos MP4/WebM/HLS/DASH.
