package com.tokilite.tv;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Classifies a media response based on its actual MIME or leading bytes.
 * A .bin suffix alone is never proof of a playable video. No DRM handling.
 */
public final class OpaqueMediaInspector {
    private OpaqueMediaInspector() { }

    /** Returns recognized MIME type, or null for unverified/binary/encrypted content. */
    public static String classify(String contentType, byte[] prefix) {
        String mime = contentType == null ? "" : contentType.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
        switch (mime) {
            case "application/vnd.apple.mpegurl":
            case "application/x-mpegurl":
            case "audio/mpegurl": return "application/x-mpegURL";
            case "application/dash+xml": return "application/dash+xml";
            case "video/mp4": return "video/mp4";
            case "video/webm": return "video/webm";
            case "video/x-matroska": return "video/x-matroska";
        }
        if (prefix == null || prefix.length < 4) return null;
        if (prefix.length >= 8 && prefix[4] == 'f' && prefix[5] == 't' &&
                prefix[6] == 'y' && prefix[7] == 'p') return "video/mp4";
        if ((prefix[0] & 0xff) == 0x1a && (prefix[1] & 0xff) == 0x45 &&
                (prefix[2] & 0xff) == 0xdf && (prefix[3] & 0xff) == 0xa3)
            return "video/webm";
        int length = Math.min(prefix.length, 256);
        String lead = new String(prefix, 0, length, StandardCharsets.UTF_8).trim();
        if (lead.startsWith("#EXTM3U")) return "application/x-mpegURL";
        if (lead.startsWith("<MPD") || (lead.startsWith("<?xml") && lead.contains("<MPD")))
            return "application/dash+xml";
        return null;
    }

    public static boolean supported(String mime) {
        return "video/mp4".equals(mime) || "video/webm".equals(mime) ||
                "video/x-matroska".equals(mime) || "application/x-mpegURL".equals(mime) ||
                "application/dash+xml".equals(mime);
    }
}
