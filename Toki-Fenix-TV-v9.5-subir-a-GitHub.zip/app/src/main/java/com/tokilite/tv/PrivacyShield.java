package com.tokilite.tv;

import java.util.Locale;

final class PrivacyShield {
    private static final String[] BLOCKED = { "doubleclick.net", "googlesyndication.com",
            "googletagmanager.com", "google-analytics.com", "googleadservices.com", "adsterra.com",
            "popads.net", "popcash.net", "exoclick.com", "propellerads.com", "hotjar.com",
            "clarity.ms", "taboola.com", "outbrain.com", "casino", "hondubet" };

    static boolean blockedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("animeav1.com") || h.endsWith(".animeav1.com")) return false;
        for (String block : BLOCKED) if (h.equals(block) || h.endsWith("." + block)) return true;
        return h.contains("hondubet");
    }
}
