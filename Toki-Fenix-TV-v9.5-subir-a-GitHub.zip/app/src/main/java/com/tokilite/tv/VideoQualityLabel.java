package com.tokilite.tv;

/** Represents the actual decoded video height; never guesses a quality badge. */
public final class VideoQualityLabel {
    private VideoQualityLabel() { }

    public static String fromVideoHeight(int height) {
        if (height <= 0) return "Calidad: —";
        final String tier = height >= 2160 ? " · 4K UHD" : height >= 1080 ? " · Full HD" :
            height >= 720 ? " · HD" : " · SD";
        return "Vídeo: " + height + "p" + tier;
    }
}
