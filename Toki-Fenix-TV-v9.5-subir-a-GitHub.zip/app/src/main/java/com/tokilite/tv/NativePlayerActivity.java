package com.tokilite.tv;

import android.app.Activity;
import android.app.Dialog;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Toki Lite Fenix TV — native Media3 player with an original, discreet TV overlay.
 * Playback source switching is offered only for VERIFIED media URLs provided by
 * the resolver; no placeholder URLs, web page iframes, DRM or token fabrication.
 */
public final class NativePlayerActivity extends Activity {
    private static final int INK = 0xFF101218;
    private static final int SURFACE = 0xE8181B24;
    private static final int ORANGE = 0xFFFF8322;
    private static final int WHITE = 0xFFF3F4F8;
    private static final int SECONDARY = 0xFFABB0BE;
    private static final long HIDE_MS = 4200;

    private ExoPlayer player;
    private PlayerView playerView;
    private FrameLayout root;
    private FrameLayout controls;
    private TextView quality, status, time, currentServer, currentAudio;
    private SeekBar seek;
    private Button playButton, serverButton;
    private boolean controlsVisible = true;
    private boolean seeking;
    private Dialog activeDialog;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Source> sources = new ArrayList<>();
    private int activeSource = 0;

    private final Runnable autoHide = () -> {
        if (player != null && player.isPlaying() && !seeking && activeDialog == null) setControlsVisible(false);
    };
    private final Runnable progress = new Runnable() {
        @Override public void run() {
            if (player != null && seek != null) {
                long duration = player.getDuration();
                long position = Math.max(0, player.getCurrentPosition());
                if (!seeking && duration > 0 && duration != C.TIME_UNSET) {
                    seek.setEnabled(true);
                    seek.setProgress((int) Math.min(1000, position * 1000L / duration));
                } else if (duration <= 0 || duration == C.TIME_UNSET) {
                    seek.setEnabled(false);
                }
                time.setText(formatTime(position) + " / " + ((duration > 0 && duration != C.TIME_UNSET) ? formatTime(duration) : "--:--"));
            }
            handler.postDelayed(this, 500);
        }
    };

    private static final class Source {
        final String url, referer, mime, audio, server;
        Source(String url, String referer, String mime, String audio, String server) {
            this.url = url; this.referer = referer; this.mime = mime;
            this.audio = audio; this.server = server;
        }
    }

    private int dp(float number) { return Math.round(number * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        loadSources();
        if (sources.isEmpty()) { finish(); return; }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusableInTouchMode(true);
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setKeepContentOnPlayerReset(true);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        makeControls();
        setContentView(root);

        // Create Media3 only once, when a verified source is selected.
        // Server changes replace only this native player, never the TV interface.
        switchToSource(0, false);
        handler.post(progress);
        playButton.requestFocus();
        scheduleHide();
    }

    private void loadSources() {
        String url = getIntent().getStringExtra("mediaUrl");
        String referer = getIntent().getStringExtra("referer");
        String mime = getIntent().getStringExtra("mimeType");
        addSafeSource(url, referer, mime, "Original", "Servidor 1");
        // Optional extra alternatives: one verified URL per array element.
        // This is a player contract, not an assertion the AnimeAV1 resolver
        // already exposes multiple independently playable servers.
        ArrayList<String> urls = getIntent().getStringArrayListExtra("sourceUrls");
        ArrayList<String> refs = getIntent().getStringArrayListExtra("sourceReferers");
        ArrayList<String> mimes = getIntent().getStringArrayListExtra("sourceMimes");
        ArrayList<String> names = getIntent().getStringArrayListExtra("sourceServers");
        ArrayList<String> modes = getIntent().getStringArrayListExtra("sourceAudios");
        if (urls != null) for (int i = 0; i < urls.size() && i < 16; i++) {
            addSafeSource(urls.get(i), at(refs, i), at(mimes, i),
                    fallback(at(modes, i), "Original"), fallback(at(names, i), "Servidor " + (i+2)));
        }
    }

    private static String at(List<String> list, int index) {
        return list != null && index < list.size() ? list.get(index) : null;
    }
    private static String fallback(String text, String fallback) {
        return text == null || text.trim().isEmpty() ? fallback : text.trim();
    }
    private void addSafeSource(String url, String referer, String mime, String audio, String server) {
        boolean opaque = TokiSourceParser.isOpaqueMediaCandidate(url) && OpaqueMediaInspector.supported(mime);
        if (!TokiStreamResolver.isDirectMediaUrl(url) && !opaque) return;
        for (Source existing : sources) if (existing.url.equals(url)) return;
        sources.add(new Source(url, TokiStreamResolver.isSafeReferer(referer) ? referer : "",
                opaque ? mime : null, audio, server));
    }

    private DefaultHttpDataSource.Factory createNetwork() {
        Source src = sources.get(activeSource);
        Map<String, String> headers = new HashMap<>();
        if (!src.referer.isEmpty()) headers.put("Referer", src.referer);
        String cookie = CookieManager.getInstance().getCookie(src.url);
        if (cookie != null && !cookie.isEmpty()) headers.put("Cookie", cookie);
        return new DefaultHttpDataSource.Factory()
                .setUserAgent(WebSettings.getDefaultUserAgent(this))
                .setDefaultRequestProperties(headers)
                .setConnectTimeoutMs(9000).setReadTimeoutMs(12000);
    }

    private void switchToSource(int nextIndex, boolean preservePosition) {
        if (nextIndex < 0 || nextIndex >= sources.size()) return;
        long oldPosition = preservePosition && player != null ? Math.max(0, player.getCurrentPosition()) : 0;
        activeSource = nextIndex;
        Source choice = sources.get(activeSource);
        // Headers may differ by authorized server. Release the previous player
        // before creating one with the correct request properties.
        if (player != null) {
            player.stop();
            player.clearMediaItems();
            player.release();
        }
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(createNetwork())).build();
        // Reconnect listener via stable helper so events survive source switches.
        bindEvents();
        playerView.setPlayer(player);
        MediaItem.Builder item = new MediaItem.Builder().setUri(choice.url);
        if (choice.mime != null) item.setMimeType(choice.mime);
        player.setMediaItem(item.build());
        player.prepare();
        if (preservePosition && oldPosition > 0) player.seekTo(oldPosition);
        player.play();
        currentServer.setText(choice.server);
        serverButton.setText("⇄  Cambiar");
        currentAudio.setText("Audio: " + choice.audio);
        quality.setText("Resolución —");
        status.setText("Preparando " + choice.server + "…");
        scheduleHide();
    }

    private void bindEvents() {
        player.addListener(new Player.Listener() {
            @Override public void onVideoSizeChanged(VideoSize size) {
                quality.setText(VideoQualityLabel.fromVideoHeight(size.height));
            }
            @Override public void onIsPlayingChanged(boolean playing) {
                playButton.setText(playing ? "Ⅱ  Pausar" : "▶  Reproducir");
                if (playing) scheduleHide(); else { handler.removeCallbacks(autoHide); setControlsVisible(true); }
            }
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) status.setText("Cargando vídeo…");
                else if (state == Player.STATE_READY) status.setText("");
                else if (state == Player.STATE_ENDED) { status.setText("Episodio terminado"); setControlsVisible(true); }
            }
            @Override public void onPlayerError(PlaybackException error) {
                status.setText("Fuente no disponible. Usa «Cambiar» si hay otro servidor o pulsa Atrás.");
                setControlsVisible(true);
            }
            @Override public void onTracksChanged(Tracks tracks) { updateAudioLabel(); }
        });
    }

    private void makeControls() {
        controls = new FrameLayout(this);
        controls.setFocusable(false);
        root.addView(controls, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(28), dp(14), dp(28), dp(14));
        top.setBackground(gradient(0xED090B10, 0x00090B10, true));
        Button back = controlButton("‹  Volver", this::finish);
        top.addView(back);
        TextView title = new TextView(this);
        title.setText(fallback(getIntent().getStringExtra("episodeTitle"), "Toki Lite Fénix TV"));
        title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextColor(WHITE); title.setTextSize(17);
        title.setPadding(dp(20), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        quality = new TextView(this);
        quality.setText("Resolución —"); quality.setTextColor(WHITE); quality.setTextSize(14);
        quality.setPadding(dp(15), dp(8), dp(15), dp(8));
        quality.setBackground(rounded(0xCA222730, dp(11), 0x803C4650));
        top.addView(quality);
        controls.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(28), dp(32), dp(28), dp(24));
        bottom.setBackground(gradient(0x00090B10, 0xED090B10, false));
        status = new TextView(this);
        status.setTextColor(0xFFE3B6A0); status.setTextSize(13);
        status.setText("Preparando…");
        bottom.addView(status);

        seek = new SeekBar(this);
        seek.setMax(1000); seek.setFocusable(true);
        seek.setProgressTintList(ColorStateList.valueOf(ORANGE));
        seek.setThumbTintList(ColorStateList.valueOf(ORANGE));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; handler.removeCallbacks(autoHide); }
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                if (player != null && player.getDuration() > 0)
                    player.seekTo(player.getDuration() * s.getProgress() / 1000L);
                scheduleHide();
            }
        });
        bottom.addView(seek, new LinearLayout.LayoutParams(-1, dp(37)));

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(0, dp(5), 0, 0);
        Button rewind = controlButton("↺  10 s", () -> jump(-10000));
        playButton = controlButton("Ⅱ  Pausar", this::togglePlay);
        Button forward = controlButton("10 s  ↻", () -> jump(10000));
        tools.addView(rewind); tools.addView(playButton); tools.addView(forward);
        time = new TextView(this);
        time.setText("0:00 / --:--");time.setTextColor(SECONDARY);time.setTextSize(14);
        time.setPadding(dp(12), 0, 0, 0);
        tools.addView(time, new LinearLayout.LayoutParams(0, -2, 1f));
        bottom.addView(tools);

        LinearLayout options = new LinearLayout(this);
        options.setGravity(Gravity.CENTER_VERTICAL);
        options.setPadding(0, dp(12), 0, 0);
        currentAudio = new TextView(this);
        currentAudio.setText("Audio: Original");
        currentAudio.setTextColor(SECONDARY); currentAudio.setTextSize(13);
        options.addView(currentAudio);
        options.addView(controlButton("♫  Audio", this::showAudioMenu));
        options.addView(controlButton("CC  Subtítulos", this::showSubtitleMenu));
        TextView gap = new TextView(this);
        options.addView(gap, new LinearLayout.LayoutParams(0, dp(1), 1f));
        currentServer = new TextView(this);
        currentServer.setText("Servidor 1");currentServer.setTextColor(WHITE);currentServer.setTextSize(14);
        currentServer.setPadding(dp(8), 0, dp(8), 0);
        options.addView(currentServer);
        serverButton = controlButton("⇄  Cambiar", this::showServerMenu);
        options.addView(serverButton);
        bottom.addView(options);
        controls.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private GradientDrawable gradient(int begin, int end, boolean down) {
        return new GradientDrawable(down ? GradientDrawable.Orientation.TOP_BOTTOM : GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{begin, end});
    }
    private GradientDrawable rounded(int bg, float r, int border) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);g.setCornerRadius(r);g.setStroke(dp(1), border);
        return g;
    }
    private Button controlButton(String text, Runnable action) {
        Button button = new Button(this);
        button.setText(text); button.setTextSize(14); button.setTextColor(WHITE);
        button.setAllCaps(false);button.setFocusable(true);
        button.setPadding(dp(9), dp(4), dp(9), dp(4));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(43));
        params.setMargins(0, 0, dp(7), 0);
        button.setLayoutParams(params);
        button.setBackground(rounded(SURFACE, dp(9), 0xFF343946));
        button.setOnFocusChangeListener((v, focused) -> {
            button.setBackground(rounded(focused ? ORANGE : SURFACE, dp(9), focused ? WHITE : 0xFF343946));
            button.setTextColor(focused ? 0xFF17100C : WHITE);
        });
        button.setOnClickListener(v -> { action.run(); if (activeDialog == null) scheduleHide(); });
        return button;
    }
    private void scheduleHide() {
        handler.removeCallbacks(autoHide);
        if (player != null && player.isPlaying() && activeDialog == null) handler.postDelayed(autoHide, HIDE_MS);
    }
    private void setControlsVisible(boolean show) {
        if (controls == null) return;
        boolean wasVisible = controlsVisible;
        controlsVisible = show;
        controls.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            if (!wasVisible || getCurrentFocus() == root) playButton.requestFocus();
            scheduleHide();
        } else root.requestFocus();
    }
    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) player.pause(); else player.play();
        setControlsVisible(true);
    }
    private void jump(long delta) {
        if (player == null || !player.isCurrentMediaItemSeekable()) return;
        long duration = player.getDuration();
        long target = Math.max(0, player.getCurrentPosition() + delta);
        if (duration > 0 && duration != C.TIME_UNSET) target = Math.min(target, duration);
        player.seekTo(target);
        setControlsVisible(true);
    }

    private interface Action { void run(); }
    private void showMenu(String title, List<String> labels, List<Action> actions) {
        if (activeDialog != null) return;
        handler.removeCallbacks(autoHide);
        Dialog dialog = new Dialog(this);
        activeDialog = dialog;
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(18), dp(20), dp(18));
        body.setBackground(rounded(0xFF151821, dp(14), 0xFF373C4C));
        TextView heading = new TextView(this);
        heading.setText(title);heading.setTextSize(21);heading.setTextColor(WHITE);
        heading.setPadding(0, 0, 0, dp(14));
        body.addView(heading);
        for (int i=0;i<labels.size();i++) {
            Action action = actions.get(i);
            Button b = controlButton(labels.get(i), () -> { dialog.dismiss(); action.run(); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(47));
            p.setMargins(0,0,0,dp(7));
            body.addView(b,p);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);scroll.addView(body);
        dialog.setContentView(scroll);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(dp(520), getResources().getDisplayMetrics().widthPixels - dp(90));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.55f;
            window.setAttributes(lp);
        }
        dialog.setOnDismissListener(d -> { activeDialog = null; setControlsVisible(true); });
        dialog.show();
        if (dialog.getWindow()!=null) dialog.getWindow().setLayout(
                Math.min(dp(520), getResources().getDisplayMetrics().widthPixels - dp(90)), -2);
        body.requestFocus();
    }

    private void showAudioMenu() {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<Action> actions = new ArrayList<>();
        // Separate source files can carry LAT/SUB/DUB even when the mux has one audio track.
        for (int i = 0; i < sources.size(); i++) {
            Source s = sources.get(i); final int k = i;
            if (!s.audio.equalsIgnoreCase("Original") || sources.size() > 1) {
                labels.add((i == activeSource ? "✓  " : "") + s.audio + "  ·  " + s.server);
                actions.add(() -> switchToSource(k, true));
            }
        }
        if (player != null) for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int t=0;t<group.length;t++) if (group.isTrackSupported(t)) {
                int index=t; String language=labelTrack(group,index);
                labels.add("♫  " + language);
                actions.add(() -> chooseTrack(group,index,C.TRACK_TYPE_AUDIO));
            }
        }
        if (labels.isEmpty()) {
            labels.add("Pista de audio única · " + sources.get(activeSource).audio);
            actions.add(() -> status.setText("Este servidor no ofrece más idiomas de audio."));
        }
        showMenu("Audio",labels,actions);
    }
    private void showSubtitleMenu() {
        ArrayList<String> labels=new ArrayList<>();ArrayList<Action> actions=new ArrayList<>();
        labels.add("Sin subtítulos");
        actions.add(() -> {
            if (player != null) player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true).build());
        });
        if (player != null) for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType()!=C.TRACK_TYPE_TEXT) continue;
            for(int t=0;t<group.length;t++) if(group.isTrackSupported(t)) {
                int index=t;
                labels.add("CC  "+labelTrack(group,index));
                actions.add(() -> chooseTrack(group,index,C.TRACK_TYPE_TEXT));
            }
        }
        showMenu("Subtítulos",labels,actions);
    }
    private static String labelTrack(Tracks.Group group,int i) {
        String label=group.getTrackFormat(i).label;
        String lang=group.getTrackFormat(i).language;
        if(label!=null&&!label.isEmpty())return label;
        if(lang!=null&&!lang.isEmpty())return new Locale(lang).getDisplayLanguage(new Locale("es"));
        return "Pista "+(i+1);
    }
    private void chooseTrack(Tracks.Group group,int i,int type) {
        if (player == null) return;
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setTrackTypeDisabled(type,false)
                .setOverrideForType(new TrackSelectionOverride(group.getMediaTrackGroup(),i)).build());
        if (type == C.TRACK_TYPE_AUDIO) currentAudio.setText("Audio: " + labelTrack(group,i));
    }
    private void updateAudioLabel() {
        if (player == null || currentAudio == null) return;
        for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() != C.TRACK_TYPE_AUDIO) continue;
            for(int i=0;i<group.length;i++) if(group.isTrackSelected(i)) {
                currentAudio.setText("Audio: " + labelTrack(group,i));return;
            }
        }
        currentAudio.setText("Audio: "+sources.get(activeSource).audio);
    }
    private void showServerMenu() {
        if (sources.size() < 2) {
            ArrayList<String> labels = new ArrayList<>();
            ArrayList<Action> actions = new ArrayList<>();
            labels.add("Solo hay un servidor multimedia verificado");
            actions.add(() -> status.setText("No se han encontrado otras fuentes reproducibles para este episodio."));
            showMenu("Cambiar servidor",labels,actions);
            return;
        }
        ArrayList<String> labels=new ArrayList<>();ArrayList<Action> actions=new ArrayList<>();
        for(int i=0;i<sources.size();i++) {
            Source source=sources.get(i);final int index=i;
            labels.add((i==activeSource?"✓  ":"")+source.server+" · "+source.audio);
            actions.add(() -> { if(index!=activeSource) switchToSource(index,true); });
        }
        showMenu("Seleccionar servidor",labels,actions);
    }
    private static String formatTime(long ms) {
        long all=Math.max(0,ms/1000), minutes=all/60, seconds=all%60;
        return String.format(Locale.US,"%d:%02d",minutes,seconds);
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent e) {
        if (keyCode==KeyEvent.KEYCODE_BACK || keyCode==KeyEvent.KEYCODE_ESCAPE) {
            if (activeDialog != null) { activeDialog.dismiss();return true; }
            finish();return true;
        }
        if (player == null) return super.onKeyDown(keyCode,e);
        if (keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode==KeyEvent.KEYCODE_MEDIA_PLAY
                || keyCode==KeyEvent.KEYCODE_MEDIA_PAUSE) { togglePlay();return true; }
        if (keyCode==KeyEvent.KEYCODE_MENU) { showAudioMenu();return true; }
        if (!controlsVisible && (keyCode==KeyEvent.KEYCODE_DPAD_UP || keyCode==KeyEvent.KEYCODE_DPAD_DOWN
                || keyCode==KeyEvent.KEYCODE_DPAD_LEFT || keyCode==KeyEvent.KEYCODE_DPAD_RIGHT
                || keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER)) {
            setControlsVisible(true);return true;
        }
        if (getCurrentFocus()==seek && (keyCode==KeyEvent.KEYCODE_DPAD_LEFT || keyCode==KeyEvent.KEYCODE_DPAD_RIGHT)) {
            jump(keyCode==KeyEvent.KEYCODE_DPAD_LEFT?-10000:10000);seek.requestFocus();return true;
        }
        scheduleHide();
        return super.onKeyDown(keyCode,e);
    }
    @Override protected void onStop(){if(player!=null)player.pause();super.onStop();}
    @Override protected void onDestroy(){
        handler.removeCallbacks(progress);handler.removeCallbacks(autoHide);
        if (activeDialog != null) { activeDialog.dismiss();activeDialog=null; }
        if (player != null) {player.release();player=null;}
        if (playerView != null) playerView.setPlayer(null);
        super.onDestroy();
    }
}
