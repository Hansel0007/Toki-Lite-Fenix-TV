package com.tokilite.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Map;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Arrays;

/**
 * Searches for media URLs that a watch page explicitly exposes during its normal playback flow.
 * No DRM decryption, CAPTCHA solving, token fabrication or anti-bot circumvention.
 * Some hosts only expose cross-origin players, in which case resolution correctly fails.
 */
public final class TokiStreamResolver {
    public interface Callback {
        void onFound(String mediaUrl, String referer, String mimeType, List<String> otherSources);
        void onFailure(String explanation);
    }
    private final Activity activity;
    private final FrameLayout root;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView probe;
    private AtomicBoolean finished = new AtomicBoolean(false);
    private String watchUrl;
    private Callback callback;
    private volatile boolean hasExternalEmbed = false;
    private final AtomicInteger opaqueProbeCount = new AtomicInteger();
    private final Set<String> opaqueProbed = Collections.newSetFromMap(new ConcurrentHashMap<>());

    TokiStreamResolver(Activity activity, FrameLayout root) { this.activity = activity; this.root = root; }

    static boolean isValidEpisodeUrl(String candidate) {
        try {
            URI u = new URI(candidate);
            return "https".equalsIgnoreCase(u.getScheme()) &&
                   "animeav1.com".equalsIgnoreCase(u.getHost()) &&
                   u.getPath().matches("/media/[A-Za-z0-9-]+/[0-9]+/?");
        } catch (Exception ex) { return false; }
    }

    static boolean isDirectMediaUrl(String candidate) {
        try {
            URI u = new URI(candidate);
            return "https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null &&
                   u.getPath().toLowerCase(java.util.Locale.ROOT).matches(".*\\.(m3u8|mp4|mpd|webm)");
        } catch (Exception ex) { return false; }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    void resolve(String episode, Callback listener) {
        cancel();
        if (!isValidEpisodeUrl(episode)) { listener.onFailure("URL de episodio no válida."); return; }
        watchUrl = episode;
        hasExternalEmbed = false;
        opaqueProbeCount.set(0);
        opaqueProbed.clear();
        callback = listener;
        finished = new AtomicBoolean(false);
        probe = new WebView(activity);
        probe.setAlpha(0.01f);
        probe.setFocusable(false);
        // WebView engines can throttle one-pixel playback surfaces. Keep an offscreen
        // render area for ordinary website video initialization, but do not expose
        // the site's player or its advertising UI.
        probe.setTranslationX(-4096f);
        probe.setTranslationY(-4096f);
        root.addView(probe, new FrameLayout.LayoutParams(640, 360));
        WebSettings settings = probe.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(probe, false);
        probe.addJavascriptInterface(new MediaBridge(), "TokiMediaProbe");
        probe.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Block offsite top-level navigation. Embedded resources can be loaded by the site.
                String host = request.getUrl().getHost();
                return PrivacyShield.blockedHost(host) || (request.isForMainFrame() &&
                       !"animeav1.com".equalsIgnoreCase(host));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                String host = req.getUrl().getHost();
                if (PrivacyShield.blockedHost(host))
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                // Observe ONLY media URLs requested in the page's ordinary playback
                // flow; do not fabricate tokens, replay signed sessions or solve
                // access challenges. The real media request remains untouched.
                final String requestUrl = req.getUrl().toString();
                if (isDirectMediaUrl(requestUrl)) {
                    Map<String, String> requestHeaders = req.getRequestHeaders();
                    String ref = null;
                    if (requestHeaders != null) {
                        for (Map.Entry<String, String> entry : requestHeaders.entrySet()) {
                            if ("referer".equalsIgnoreCase(entry.getKey())) {
                                ref = entry.getValue();
                                break;
                            }
                        }
                    }
                    final String safeReferer = isSafeReferer(ref) ? ref : watchUrl;
                    main.post(() -> new MediaBridge().foundWithReferer(requestUrl, safeReferer));
                } else if (TokiSourceParser.isOpaqueMediaCandidate(requestUrl)) {
                    // The request is allowed to continue normally. Independently verify
                    // a bounded number of opaque media candidates; never trust .bin alone.
                    Map<String, String> requestHeaders = req.getRequestHeaders();
                    String ref = requestHeaders == null ? null : requestHeaders.get("Referer");
                    inspectOpaqueCandidate(requestUrl, isSafeReferer(ref) ? ref : watchUrl, finished);
                }
                return null;
            }
            @Override public void onPageFinished(WebView view, String url) { installProbe(view); }
        });
        probe.loadUrl(episode);
        // UKIKU-style first phase: inspect declared HTML/media metadata as DATA,
        // not as a navigable player page. A working direct source is delivered to Media3.
        inspectPublishedPage(episode, finished);
        // Never trap the user in a permanent loading screen.
        AtomicBoolean current = finished;
        main.postDelayed(() -> { if (current == finished) fail(hasExternalEmbed
            ? "Toki expone un reproductor externo, pero aún no una fuente multimedia directa compatible con Media3."
            : "Toki no publicó una fuente MP4/HLS/DASH utilizable. No se intentará reproducir HTML como vídeo."); }, 11000);
    }

    private void inspectPublishedPage(String episode, AtomicBoolean requestState) {
        final String cookie = CookieManager.getInstance().getCookie(episode);
        final String ua = WebSettings.getDefaultUserAgent(activity);
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(episode).openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("User-Agent", ua);
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                if (cookie != null && !cookie.isEmpty()) conn.setRequestProperty("Cookie", cookie);
                if (conn.getResponseCode() != 200) return;
                String type = conn.getContentType();
                if (type == null || !type.toLowerCase(java.util.Locale.ROOT).contains("text/html")) return;
                try (InputStream in = conn.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int read;
                    while ((read = in.read(buf)) > 0 && bytes.size() < 2_000_000)
                        bytes.write(buf, 0, Math.min(read, 2_000_000 - bytes.size()));
                    String html = bytes.toString("UTF-8");
                    List<String> urls = TokiSourceParser.findDirectMedia(html, episode);
                    hasExternalEmbed = !TokiSourceParser.findEmbedPages(html, episode).isEmpty();
                    for (String opaque : TokiSourceParser.findOpaqueMediaCandidates(html, episode))
                        inspectOpaqueCandidate(opaque, episode, requestState);
                    if (!urls.isEmpty()) {
                        String url = urls.get(0);
                        main.post(() -> {
                            if (requestState == finished && !finished.get())
                                new MediaBridge().foundWithReferer(url, episode, urls.subList(1, Math.min(urls.size(), 9)));
                        });
                    }
                }
            } catch (Exception ignored) {
                // The page may require JavaScript. The ordinary WebView request observer
                // is still active. Never fail early solely on static HTML errors.
            } finally { if (conn != null) conn.disconnect(); }
        }, "toki-page-metadata").start();
    }

    /** Validate opaque URL using MIME + at most 512 response bytes, no access-control bypass. */
    private void inspectOpaqueCandidate(String candidate, String referer, AtomicBoolean requestState) {
        if (!TokiSourceParser.isOpaqueMediaCandidate(candidate) ||
                PrivacyShield.blockedHost(hostOf(candidate)) ||
                !opaqueProbed.add(candidate) || opaqueProbeCount.incrementAndGet() > 4) return;
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(candidate).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(3500);
                conn.setReadTimeout(3500);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("Range", "bytes=0-511");
                conn.setRequestProperty("Accept-Encoding", "identity");
                conn.setRequestProperty("User-Agent", WebSettings.getDefaultUserAgent(activity));
                if (isSafeReferer(referer)) conn.setRequestProperty("Referer", referer);
                String cookies = CookieManager.getInstance().getCookie(candidate);
                if (cookies != null && !cookies.isEmpty()) conn.setRequestProperty("Cookie", cookies);
                int status = conn.getResponseCode();
                if (status != 200 && status != 206) return;
                byte[] data = new byte[512];
                int used = 0;
                try (InputStream in = conn.getInputStream()) {
                    while (used < data.length) {
                        int n = in.read(data, used, data.length-used);
                        if (n < 0) break;
                        used += n;
                    }
                }
                String mime = OpaqueMediaInspector.classify(conn.getContentType(), Arrays.copyOf(data, used));
                if (OpaqueMediaInspector.supported(mime)) {
                    main.post(() -> {
                        if (requestState == finished && !finished.get())
                            new MediaBridge().foundVerifiedOpaque(candidate, referer, mime);
                    });
                }
            } catch (Exception ignored) { /* unavailable, unsupported, or access restricted */ }
            finally { if (conn != null) conn.disconnect(); }
        }, "toki-opaque-media-check").start();
    }

    static boolean isSafeReferer(String value) {
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
        } catch (Exception e) { return false; }
    }

    private void installProbe(WebView view) {
        String script = "(function(){" +
            "if(window.__tokiMediaProbe)return;window.__tokiMediaProbe=1;" +
            "function scan(){for(const el of document.querySelectorAll('video,video source')){" +
            "const s=el.currentSrc||el.src||el.getAttribute('src');" +
            "if(s&&/^https:\\/\\//i.test(s)&&/\\.(m3u8|mp4|mpd|webm)([?#]|$)/i.test(s)){" +
            "window.TokiMediaProbe.found(s);return;}" +
            "if(s&&s.indexOf('https://')===0&&/\\.bin([?#]|$)/i.test(s)){window.TokiMediaProbe.opaque(s);return;}}}" +
            "new MutationObserver(scan).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['src']});" +
            "scan();let n=0;const t=setInterval(()=>{scan();if(++n>18)clearInterval(t)},500);})();";
        view.evaluateJavascript(script, null);
    }

    private final class MediaBridge {
        @JavascriptInterface public void found(String mediaUrl) {
            foundWithReferer(mediaUrl, watchUrl);
        }
        @JavascriptInterface public void opaque(String mediaUrl) {
            inspectOpaqueCandidate(mediaUrl, watchUrl, finished);
        }
        void foundVerifiedOpaque(String url, String referer, String mime) {
            if (!TokiSourceParser.isOpaqueMediaCandidate(url) ||
                    !OpaqueMediaInspector.supported(mime) || PrivacyShield.blockedHost(hostOf(url))) return;
            main.post(() -> {
                if (!finished.compareAndSet(false, true)) return;
                if (callback != null) callback.onFound(url, isSafeReferer(referer) ? referer : watchUrl, mime, Collections.emptyList());
                destroyProbe();
            });
        }
        void foundWithReferer(String mediaUrl, String referer) {
            foundWithReferer(mediaUrl, referer, Collections.emptyList());
        }
        void foundWithReferer(String mediaUrl, String referer, List<String> alternatives) {
            if (!isDirectMediaUrl(mediaUrl) || PrivacyShield.blockedHost(hostOf(mediaUrl))) return;
            // Only accept other explicit direct multimedia URLs, never embeds or web pages.
            List<String> safeAlternatives = new java.util.ArrayList<>();
            for (String candidate : alternatives) {
                if (safeAlternatives.size() >= 8) break;
                if (!mediaUrl.equals(candidate) && isDirectMediaUrl(candidate) &&
                        !PrivacyShield.blockedHost(hostOf(candidate)) &&
                        !safeAlternatives.contains(candidate)) safeAlternatives.add(candidate);
            }
            main.post(() -> {
                if (!finished.compareAndSet(false, true)) return;
                if (callback != null) callback.onFound(mediaUrl,
                        isSafeReferer(referer) ? referer : watchUrl, null, safeAlternatives);
                destroyProbe();
            });
        }
    }

    private static String hostOf(String mediaUrl) {
        try { return new URI(mediaUrl).getHost(); } catch (Exception ignored) { return null; }
    }

    private void fail(String text) {
        if (!finished.compareAndSet(false, true)) return;
        if (callback != null) callback.onFailure(text);
        destroyProbe();
    }
    void cancel() {
        finished.set(true);
        destroyProbe();
    }
    private void destroyProbe() {
        if (probe != null) {
            probe.stopLoading();
            probe.setWebViewClient(null);
            probe.removeJavascriptInterface("TokiMediaProbe");
            root.removeView(probe);
            probe.destroy();
            probe = null;
        }
    }
}
