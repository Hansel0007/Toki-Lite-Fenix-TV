package com.tokilite.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import org.json.JSONObject;

/** Independent TV interface. No TikAnime affiliation; no external analytics. */
public final class MainActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView ui;
    private FrameLayout root;
    private TokiStreamResolver resolver;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 10, 15));
        resolver = new TokiStreamResolver(this, root);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.rgb(8, 10, 15));
        WebSettings settings = ui.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setLoadsImagesAutomatically(true);
        settings.setSafeBrowsingEnabled(true);
        settings.setGeolocationEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(ui, false);

        ui.addJavascriptInterface(new TvBridge(), "TokiNative");
        ui.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // UI is an in-memory document. All site browsing is performed via its fetch API.
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (PrivacyShield.blockedHost(host))
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                return null;
            }
        });
        root.addView(ui, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        ui.requestFocus();
        // Do not show a splash while waiting for remote content. Render the local shell immediately.
        String script = readAsset("tv.js");
        String html = "<!doctype html><html lang='es'><head><meta charset='utf-8'>" +
                "<meta name='viewport' content='width=1280,initial-scale=1,user-scalable=no'>" +
                "</head><body style='margin:0;background:#090a0f;color:#fff'></body><script>" +
                script.replace("</script", "<\\/script") + "</script></html>";
        ui.loadDataWithBaseURL("https://animeav1.com/", html, "text/html", "UTF-8", null);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            for (int len; (len = in.read(buffer)) != -1;) out.write(buffer, 0, len);
            return out.toString("UTF-8");
        } catch (Exception e) { return "document.body.textContent='Error: faltan archivos locales de la interfaz';"; }
    }

    private final class TvBridge {
        @JavascriptInterface public void requestEpisode(String watchUrl, String episodeTitle) {
            if (!TokiStreamResolver.isValidEpisodeUrl(watchUrl)) return;
            main.post(() -> resolver.resolve(watchUrl, new TokiStreamResolver.Callback() {
                @Override public void onFound(String mediaUrl, String referer, String mimeType, java.util.List<String> alternatives) {
                    main.post(() -> {
                        if (isFinishing()) return;
                        // Clear the pending modal BEFORE opening Media3; otherwise
                        // returning from the player leaves an invisible overlay that
                        // traps Fire TV D-pad focus indefinitely.
                        if (ui != null) ui.evaluateJavascript(
                            "window.__tokiTVPlayerOpened&&window.__tokiTVPlayerOpened()", null);
                        Intent intent = new Intent(MainActivity.this, NativePlayerActivity.class);
                        intent.putExtra("mediaUrl", mediaUrl);
                        intent.putExtra("episodeTitle", episodeTitle == null ? "Toki Lite Fénix TV" : episodeTitle.substring(0, Math.min(140, episodeTitle.length())));
                        intent.putExtra("referer", referer);
                        if (mimeType != null) intent.putExtra("mimeType", mimeType);
                        // Pass only actual, validated multimedia alternatives to the
                        // native TV selector; their availability is not assumed.
                        if (alternatives != null && !alternatives.isEmpty()) {
                            java.util.ArrayList<String> urls = new java.util.ArrayList<>();
                            java.util.ArrayList<String> refs = new java.util.ArrayList<>();
                            java.util.ArrayList<String> names = new java.util.ArrayList<>();
                            for (String candidate : alternatives) {
                                if (!TokiStreamResolver.isDirectMediaUrl(candidate) || urls.size() >= 8) continue;
                                urls.add(candidate);
                                refs.add(referer);
                                names.add("Servidor " + (urls.size() + 1));
                            }
                            intent.putStringArrayListExtra("sourceUrls", urls);
                            intent.putStringArrayListExtra("sourceReferers", refs);
                            intent.putStringArrayListExtra("sourceServers", names);
                        }
                        startActivity(intent);
                    });
                }
                @Override public void onFailure(String reason) {
                    main.post(() -> {
                        if (ui != null) ui.evaluateJavascript(
                            "window.__tokiTVPlayerError&&window.__tokiTVPlayerError("+JSONObject.quote(reason)+")", null);
                    });
                }
            }));
        }
        @JavascriptInterface public void cancelResolve() { main.post(() -> resolver.cancel()); }
    }

    @Override public void onBackPressed() {
        if (ui != null) ui.evaluateJavascript("window.__tokiTVBack&&window.__tokiTVBack()", null);
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); if (ui != null) ui.onPause(); }
    @Override protected void onResume() {
        super.onResume();
        if (ui != null) {
            ui.onResume();
            // Also heal an overlay left by a system-initiated player return.
            ui.evaluateJavascript("window.__tokiTVPlayerReturned&&window.__tokiTVPlayerReturned()", null);
        }
    }
    @Override protected void onDestroy() {
        resolver.cancel();
        if (ui != null) { ui.destroy(); ui = null; }
        super.onDestroy();
    }
}
