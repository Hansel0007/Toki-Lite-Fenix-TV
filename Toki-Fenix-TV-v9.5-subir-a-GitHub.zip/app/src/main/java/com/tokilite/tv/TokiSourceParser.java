package com.tokilite.tv;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses media URLs which a page publishes in its HTML or JS state.
 * Does not execute remote JavaScript, decrypt DRM, resolve signed tokens,
 * defeat challenges, or treat an embedded HTML player as a video stream.
 *
 * Deliberately has no Android dependencies so its behavior is unit-testable.
 */
public final class TokiSourceParser {
    private static final int MAX_HTML_SIZE = 4_000_000;
    private static final Pattern HTML_MEDIA_ATTR = Pattern.compile(
        "(?is)<(?:video|source)\\b[^>]*?\\b(?:src|data-src)\\s*=\\s*['\"]([^'\"]+)['\"]");
    private static final Pattern DATA_MEDIA_ATTR = Pattern.compile(
        "(?is)\\b(?:data-video|data-file|data-hls|data-stream|data-mp4|data-url)\\s*=\\s*['\"]([^'\"]+)['\"]");
    private static final Pattern JSON_MEDIA_FIELD = Pattern.compile(
        "(?is)[\"'](?:file|src|source|stream|streamUrl|videoUrl|hls|mp4|playlist)[\"']\\s*:\\s*[\"']([^\"']+)[\"']");
    private static final Pattern HTTP_MEDIA_LITERAL = Pattern.compile(
        "(?i)https?:?\\\\?/\\\\?/[^\\s\"'<>]+?\\.(?:m3u8|mp4|mpd|webm)(?:\\?[^\\s\"'<>]*)?");
    // An opaque URL is a CANDIDATE, not proof of video. It must be
    // confirmed by HTTP Content-Type or container bytes before playback.
    private static final Pattern OPAQUE_MEDIA_SUFFIX = Pattern.compile("(?i)\\.bin$");
    private static final Pattern IFRAME_SRC = Pattern.compile(
        "(?is)<iframe\\b[^>]*?\\bsrc\\s*=\\s*['\"]([^'\"]+)['\"]");

    private TokiSourceParser() { }

    /** Returns direct HTTP(S) media links only. Maintains source order. */
    public static List<String> findDirectMedia(String html, String episodeUrl) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (html == null || html.length() > MAX_HTML_SIZE) return new ArrayList<>(urls);
        scan(HTML_MEDIA_ATTR, html, episodeUrl, urls, true);
        scan(DATA_MEDIA_ATTR, html, episodeUrl, urls, true);
        scan(JSON_MEDIA_FIELD, html, episodeUrl, urls, true);
        scan(HTTP_MEDIA_LITERAL, html, episodeUrl, urls, true);
        return new ArrayList<>(urls);
    }

    /** Candidate opaque links from explicit media attributes only (not arbitrary anchors). */
    public static List<String> findOpaqueMediaCandidates(String html, String episodeUrl) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (html == null || html.length() > MAX_HTML_SIZE) return new ArrayList<>(urls);
        for (Pattern pattern : new Pattern[] { HTML_MEDIA_ATTR, DATA_MEDIA_ATTR, JSON_MEDIA_FIELD }) {
            Matcher match = pattern.matcher(html);
            while (match.find() && urls.size() < 10) {
                String url = normalize(match.group(1), episodeUrl);
                if (isOpaqueMediaCandidate(url)) urls.add(url);
            }
        }
        return new ArrayList<>(urls);
    }

    public static boolean isOpaqueMediaCandidate(String candidate) {
        try {
            URI uri = new URI(candidate);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null &&
                   uri.getUserInfo() == null &&
                   OPAQUE_MEDIA_SUFFIX.matcher(uri.getPath()).find();
        } catch (Exception ignored) { return false; }
    }

    /** Player pages are discovered only as diagnostics, never supplied to Media3. */
    public static List<String> findEmbedPages(String html, String episodeUrl) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (html == null || html.length() > MAX_HTML_SIZE) return new ArrayList<>(urls);
        scan(IFRAME_SRC, html, episodeUrl, urls, false);
        return new ArrayList<>(urls);
    }

    private static void scan(Pattern pattern, String html, String episodeUrl,
                             LinkedHashSet<String> output, boolean requireMedia) {
        Matcher m = pattern.matcher(html);
        while (m.find() && output.size() < 30) {
            String candidate = m.groupCount() == 0 ? m.group() : m.group(1);
            String normalized = normalize(candidate, episodeUrl);
            if (normalized == null) continue;
            if (requireMedia ? isDirectMediaUrl(normalized) : isAllowedEmbed(normalized))
                output.add(normalized);
        }
    }

    public static boolean isDirectMediaUrl(String candidate) {
        try {
            URI u = new URI(candidate);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null) return false;
            String path = u.getPath().toLowerCase(Locale.ROOT);
            return path.endsWith(".m3u8") || path.endsWith(".mp4") ||
                   path.endsWith(".mpd") || path.endsWith(".webm");
        } catch (Exception e) { return false; }
    }

    private static boolean isAllowedEmbed(String candidate) {
        try {
            URI u = new URI(candidate);
            return "https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null &&
                    !isDirectMediaUrl(candidate);
        } catch (Exception e) { return false; }
    }

    static String normalize(String raw, String pageUrl) {
        if (raw == null) return null;
        try {
            String s = raw.trim();
            // Decode only literal JSON/HTML escapes; do not execute arbitrary JS.
            for (int i = 0; i < 4; i++) {
                String next = s.replace("\\\\/", "/").replace("\\/", "/")
                        .replace("\\\\u0026", "&").replace("\\u0026", "&")
                        .replace("\\\\u003d", "=").replace("\\u003d", "=")
                        .replace("&amp;", "&").replace("&#38;", "&");
                if (next.equals(s)) break;
                s = next;
            }
            // No executable, inline or binary data URLs.
            if (s.startsWith("javascript:") || s.startsWith("data:") || s.startsWith("blob:"))
                return null;
            if (s.startsWith("//")) s = "https:" + s;
            URI base = new URI(pageUrl);
            URI resolved = base.resolve(s).normalize();
            if (!"https".equalsIgnoreCase(resolved.getScheme()) || resolved.getHost() == null ||
                    resolved.getUserInfo() != null) return null;
            return resolved.toString();
        } catch (Exception e) { return null; }
    }
}
