/* Toki Lite Fénix TV v7 — interfaz TV local, cargador de catálogo asíncrono. */
(function () {
  'use strict';
  if (window.__tokiTVInstalled) return;
  window.__tokiTVInstalled = true;
  var SITE = 'https://animeav1.com';
  var GENRES = [
    ['Destacados','popular'],['Últimos añadidos','recientes'],['Catálogo completo','todos'],['A–Z','az'],
    ['Acción','accion'],['Aventura','aventura'],['Comedia','comedia'],
    ['Drama','drama'],['Fantasía','fantasia'],['Romance','romance'],
    ['Sobrenatural','sobrenatural'],['Misterio','misterio'],
    ['Ciencia ficción','ciencia-ficcion'],['Deportes','deportes'],
    ['Psicológico','psicologico'],['Recuentos de la vida','recuentos-de-la-vida']
  ];
  function norm(s){return String(s||'').replace(/\s+/g,' ').trim();}
  function txt(n){return norm(n&&n.textContent);}
  function lower(s){return norm(s).toLowerCase();}
  function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function url(u,base){try {var v=new URL(u,base||SITE+'/');return v.protocol==='https:'?v.href:'';}catch(e){return '';}}
  function site(href){try{return new URL(href).hostname==='animeav1.com';}catch(e){return false;}}
  function seriesUrl(href){try{var u=new URL(href,location.href);return u.hostname==='animeav1.com'&&/^\/media\/[a-z0-9-]+\/?$/i.test(u.pathname);}catch(e){return false;}}
  function watchUrl(href){try{var u=new URL(href,location.href);return u.hostname==='animeav1.com'&&/^\/media\/[a-z0-9-]+\/\d+\/?$/i.test(u.pathname);}catch(e){return false;}}
  function getImg(img,base){
    if(!img)return '';
    var sources=[img.getAttribute('data-src'),img.getAttribute('src'),img.currentSrc];
    var ss=img.getAttribute('data-srcset')||img.getAttribute('srcset')||'';
    if(ss)sources.push(ss.split(',')[0].trim().split(/\s+/)[0]);
    for(var i=0;i<sources.length;i++){var found=url(sources[i],base);if(found)return found;}
    return '';
  }
  function fromAnchor(a,base){
    var href=url(a.getAttribute('href'),base);if(!seriesUrl(href))return null;
    var im=a.querySelector('img');
    var raw=norm((im&&im.getAttribute('alt'))||txt(a.querySelector('h3,h4,strong'))||txt(a));
    var title=raw.replace(/^(?:Portada de|Póster de|Backdrop de|Ver)\s+/i,'')
      .replace(/^(?:\d+\s+)?(?:(?:LAT|CAST|SUB|DOB|DUB[- ]ES|Ep\s*\d+)[\s·–-]*)+/gi,'').trim();
    if(!title||/^(?:image|portada|anime|ver anime)$/i.test(title)){
      title=norm((new URL(href)).pathname.split('/').filter(Boolean).pop().replace(/-/g,' '));
    }
    if(!im){
      // Some AnimeAV1 cards render the cover and "Ver X" as siblings.
      var parent=a.parentElement;
      for(var depth=0;depth<3&&parent&&!im;depth++,parent=parent.parentElement){
        var images=Array.from(parent.querySelectorAll('img')).filter(function(i){
          return /portada|p[oó]ster/i.test(i.alt||'') || lower(i.alt).includes(lower(title));
        });
        if(images.length===1)im=images[0];
        if(parent.querySelectorAll('a[href*="/media/"]').length>5)break;
      }
    }
    if(title.length<2)return null;
    return {url:href,title:title.slice(0,100),img:getImg(im,base)};
  }
  function unique(items){
    var map=new Map(),out=[];
    items.forEach(function(it){if(!it||!it.url)return;
      var old=map.get(it.url);
      if(old){if(!old.img&&it.img)old.img=it.img;if(!old.description&&it.description)old.description=it.description;return;}
      map.set(it.url,it);out.push(it);
    });return out;
  }
  function readSeries(root,base){return unique(Array.from(root.querySelectorAll('a[href]')).map(function(a){return fromAnchor(a,base);}));}
  function sectionForHeading(h){
    var cur=h.parentElement,best=null;
    for(var i=0;i<5&&cur;i++,cur=cur.parentElement){
      var count=cur.querySelectorAll('a[href*="/media/"]').length;
      if(count>=2 && count<=70){best=cur;break;}
    }
    return best||h.parentElement||document;
  }
  var catalogDoc = document;
  function findSection(re){
    var headings=Array.from(catalogDoc.querySelectorAll('h2,h3'));
    var h=headings.find(function(n){return re.test(txt(n));});return h?sectionForHeading(h):null;
  }
  function homeSeries(){return readSeries(catalogDoc,SITE+'/').slice(0,200);}
  function recents(){
    var root=findSection(/episodios|recientemente actualizado/i)||catalogDoc;
    return unique(Array.from(root.querySelectorAll('a[href]')).map(function(a){
      var href=url(a.getAttribute('href'),SITE+'/');if(!watchUrl(href))return null;
      var n=Number((href.match(/\/(\d+)\/?$/)||[])[1]||0);
      var slug=(href.match(/\/media\/([^/]+)/)||[])[1]||'';
      var title=norm(txt(a)||'');
      title=title.replace(/^ver\s+/i,'').replace(/\s+\d+$/,'').trim();
      if(!title||title.length<2||/^episodio\s*\d+$/i.test(title))title=slug.replace(/-/g,' ');
      return {url:href,title:title,number:n,img:getImg(a.querySelector('img'),SITE+'/')};
    })).slice(0,24);
  }

  // Watch page is the top-level document, not a framed web page.
  if(/^\/media\/[^/]+\/\d+\/?$/i.test(location.pathname)) {
    var lastDismiss=0, playerReady=false, lastFocused=null;
    var clean=document.createElement('style');clean.id='tftv-watch-css';clean.textContent=`
      html,body{background:#000!important;min-height:100vh!important;overflow:hidden!important}
      header,footer,nav,[class*="comment"],[id*="comment"],
      [class*="ad-slot"],[id*="ad-slot"],[class*="advert"],[id*="advert"],
      [class*="banner-ad"],[id*="banner-ad"],[class*="popup-ad"],[id*="popup-ad"]{display:none!important}
      #tftv-player-toolbar{position:fixed;z-index:2147483646;top:0;left:0;right:0;height:72px;display:flex;
        align-items:center;gap:14px;padding:10px 22px;background:linear-gradient(#0b0d11f2,#101014d0);color:#fff;
        font:700 18px Roboto,Arial,sans-serif;box-sizing:border-box}
      #tftv-player-toolbar button,#tftv-player-options button{color:white;background:#20232d;border:1px solid #666;
        border-radius:8px;padding:12px 19px;font:700 17px Roboto,Arial,sans-serif;min-height:43px}
      #tftv-player-toolbar button:focus,#tftv-player-options button:focus{outline:4px solid #ff952a!important;background:#ae561b!important}
      #tftv-player-toolbar .title{flex:1;color:#d7d9dd;font-size:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      #tftv-player-options{position:fixed;right:16px;top:83px;width:360px;max-height:calc(100vh - 100px);
        overflow:auto;z-index:2147483646;background:#13161ef7;border:1px solid #414652;border-radius:12px;
        padding:18px;color:#fff;font:16px Roboto,Arial,sans-serif;box-sizing:border-box;display:none}
      #tftv-player-options.open{display:block}#tftv-player-options h3{margin:8px 0 12px;font-size:19px}
      #tftv-player-options button{display:block;width:100%;text-align:left;margin:6px 0}
      #tftv-player-options .help{font-size:13px;color:#adb2be;line-height:1.4}
      #tftv-player-dark{position:fixed;inset:0;background:#000;z-index:2147483640;pointer-events:none}
      #tftv-player-info{position:fixed;z-index:2147483644;bottom:20px;left:25px;right:25px;color:#cbd0d9;
        background:#10121abb;padding:12px 18px;border:1px solid #333;border-radius:8px;font:16px Roboto,Arial;max-width:950px}
      #tftv-player-screen{background:#000;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;
        max-width:none!important;max-height:none!important;border:0!important;object-fit:contain!important;z-index:2147483642!important}
    `;
    (document.head||document.documentElement).appendChild(clean);
    function darkenSite(){if(!document.body||document.getElementById('tftv-player-dark'))return;var bg=document.createElement('div');bg.id='tftv-player-dark';document.body.appendChild(bg);}
    darkenSite();
    function dismissDialogs(){
      var btns=Array.from(document.querySelectorAll('button,[role="button"]')).filter(function(b){return !b.closest('#tftv-player-toolbar,#tftv-player-options');});
      var now=Date.now();
      ['ahora no','entendido'].forEach(function(label){var b=btns.find(function(el){return lower(txt(el))===label;});
        if(b&&now-lastDismiss>250){lastDismiss=now;b.click();}});
      Array.from(document.querySelectorAll('[role="dialog"],dialog,[class*="modal"],[class*="Modal"]')).forEach(function(d){
        if(d.closest('#tftv-player-toolbar,#tftv-player-options'))return;
        if(!/gestos del reproductor|ayúdanos a mantener toki gratis|bienvenido a toki/i.test(txt(d)))return;
        var c=Array.from(d.querySelectorAll('button,[role="button"]')).find(function(b){return /^(entendido|ahora no|×|✕|cerrar)$/i.test(txt(b))||/close|cerrar/i.test(b.getAttribute('aria-label')||'');});
        if(c)c.click();else d.style.setProperty('display','none','important');
      });
    }
    function goBack(){
      // Back navigation is managed by the native WebView as a safe fallback.
      // The home page restores the saved series from sessionStorage.
      location.assign(SITE+'/');
    }
    window.__tokiTVBack=goBack;
    function findVideo(){return document.querySelector('video:not([data-ad]),video');}
    function audioOptions(){
      var labels=['Subtitulado','Latino','DUB-ES','Castellano','Español','Japonés'];
      var found=[];
      Array.from(document.querySelectorAll('button,[role="button"],select option')).forEach(function(el){
        if(el.closest('#tftv-player-toolbar,#tftv-player-options'))return;
        var label=txt(el);if(labels.some(function(l){return lower(label)===lower(l)})&& !found.some(function(x){return lower(x.label)===lower(label)}))found.push({label:label,el:el});
      });return found;
    }
    function showOptions(){
      var pane=document.getElementById('tftv-player-options');if(!pane)return;
      var options=audioOptions();pane.innerHTML='<h3>Audio y subtítulos</h3>';
      if(options.length){options.forEach(function(opt){var b=document.createElement('button');b.textContent=opt.label;b.onclick=function(){opt.el.click();pane.classList.remove('open');document.getElementById('tftv-settings').focus();};pane.appendChild(b);});}
      else {var p=document.createElement('p');p.className='help';p.textContent='Este servidor no expone opciones de idioma accesibles a la app. Prueba otro servidor desde la página del episodio.';pane.appendChild(p);}
      var video=findVideo();if(video&&video.textTracks&&video.textTracks.length){
        for(var i=0;i<video.textTracks.length;i++)(function(track){var b=document.createElement('button');b.textContent='Subtítulos: '+(track.label||track.language||'Pista');b.onclick=function(){Array.from(video.textTracks).forEach(function(t){t.mode=t===track?'showing':'disabled';});pane.classList.remove('open');};pane.appendChild(b);})(video.textTracks[i]);
      }
      var exit=document.createElement('button');exit.textContent='Cerrar opciones';exit.onclick=function(){pane.classList.remove('open');document.getElementById('tftv-settings').focus();};pane.appendChild(exit);
      pane.classList.add('open');var first=pane.querySelector('button');if(first)first.focus();
    }
    function createToolbar(){
      if(document.getElementById('tftv-player-toolbar')||!document.body)return;
      var bar=document.createElement('div');bar.id='tftv-player-toolbar';
      bar.innerHTML='<button id="tftv-back">← Volver</button><span class="title">Toki Lite Fénix TV · Reproductor</span><button id="tftv-play">⏯ Reproducir / Pausar</button><button id="tftv-settings">⚙ Audio / subtítulos</button>';
      document.body.appendChild(bar);
      var options=document.createElement('div');options.id='tftv-player-options';document.body.appendChild(options);
      document.getElementById('tftv-back').onclick=goBack;
      document.getElementById('tftv-play').onclick=function(){var v=findVideo();if(v){if(v.paused)v.play().catch(function(){});else v.pause();}};
      document.getElementById('tftv-settings').onclick=showOptions;
      document.getElementById('tftv-back').focus();
    }
    function showMediaStatus(message){
      var el=document.getElementById('tftv-player-info');
      if(!el){el=document.createElement('div');el.id='tftv-player-info';document.body.appendChild(el);}
      el.textContent=message;
    }
    function fitVideo(){
      var video=findVideo();if(video){if(video.id!=='tftv-player-screen')video.id='tftv-player-screen';playerReady=true;var info=document.getElementById('tftv-player-info');if(info)info.remove();return;}
      // Some providers use a cross-origin iframe. Preserve the original iframe
      // rather than inventing a media URL or violating iframe origin controls.
      var f=Array.from(document.querySelectorAll('iframe[src]')).find(function(n){return !/casino|banner|advert|googleads|doubleclick/i.test(n.src);});
      if(f){f.id='tftv-player-screen';playerReady=true;showMediaStatus('Este servidor usa un reproductor externo. Algunas funciones del control podrían no estar disponibles. Pulsa ← Volver para regresar a la serie.');}
    }
    function sweep(){darkenSite();dismissDialogs();createToolbar();fitVideo();}
    document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible')sweep();});
    sweep();
    if(!playerReady)showMediaStatus('Buscando una fuente multimedia compatible. Si este episodio solo ofrece un reproductor externo, podría no funcionar con el control.');
    var lastSweep=0;var observer=new MutationObserver(function(){var now=Date.now();if(now-lastSweep<180)return;lastSweep=now;sweep();});
    observer.observe(document.documentElement,{childList:true,subtree:true});
    document.addEventListener('keydown',function(e){
      if(['Escape','Backspace','BrowserBack'].indexOf(e.key)>=0){e.preventDefault();goBack();return;}
      var pane=document.getElementById('tftv-player-options');
      if(pane&&pane.classList.contains('open')&&e.key==='ArrowLeft'){e.preventDefault();pane.classList.remove('open');document.getElementById('tftv-settings').focus();return;}
      var v=findVideo();if(v&&!pane.classList.contains('open')){
        if(e.key==='MediaPlayPause'){e.preventDefault();v.paused?v.play().catch(function(){}):v.pause();}
        if(e.key==='ArrowRight'&&document.activeElement===v){e.preventDefault();v.currentTime=Math.min(v.duration||v.currentTime+10,v.currentTime+10);}
        if(e.key==='ArrowLeft'&&document.activeElement===v){e.preventDefault();v.currentTime=Math.max(0,v.currentTime-10);}
      }
    },true);
    return;
  }
  // App shell local: no dependemos de pathname ni de la página original.

  var popRoot=findSection(/^top 10 de la semana$/i)||findSection(/top 10/i);
  var popular=popRoot?readSeries(popRoot,location.href):[];
  var ALL=homeSeries();
  if(!popular.length)popular=ALL.slice(0,12);
  var RECENT=recents();
  var SECTIONS=[];
  Array.from(catalogDoc.querySelectorAll('h2')).forEach(function(h){
    var title=txt(h);if(!/^(Acción|Aventura|Fantasía|Drama|Romance|Comedia|Películas|Top valorados|Estrenos recientes|En emisión esta semana|Joyas ocultas)$/i.test(title))return;
    var records=readSeries(sectionForHeading(h),location.href).slice(0,18);
    if(records.length>1)SECTIONS.push({title:title,items:records});
  });
  ALL=unique(popular.concat(SECTIONS.reduce(function(a,s){return a.concat(s.items);},[])).concat(ALL));
  var state={screen:'home',tab:'episodes',series:null,episodes:[],season:0,seasons:[],selectedGenre:'popular',genreResults:[],genrePage:0,genreNoMore:false,search:'',busy:false};
  var catalogPage=0, maxCatalogPage=50, catalogLoading=false;
  function loadCatalog(){
    // Fetch public metadata, not a rendering of the third-party website.
    fetchPage(SITE+'/').then(function(doc){
      catalogDoc=doc;
      var featured=homeSeries();
      popular=featured.slice(0,18);
      RECENT=recents();
      SECTIONS=[];
      Array.from(doc.querySelectorAll('h2')).forEach(function(h){
        var title=txt(h);
        if(!/recientemente agregados|destacados|mejor valorados|populares|en emisi[oó]n/i.test(title))return;
        var records=readSeries(sectionForHeading(h),SITE+'/').slice(0,20);
        if(records.length>1)SECTIONS.push({title:title,items:records});
      });
      ALL=unique(popular.concat(SECTIONS.reduce(function(a,x){return a.concat(x.items);},[])).concat(ALL));
      if(state.screen==='home'||state.screen==='explore')render();
      loadHero();
    }).catch(function(){if(state.screen==='home'||state.screen==='explore')render();});
    if(!catalogPage)loadCatalogPage(false);
  }
  function renderCatalogPreservingScroll(){
    if(state.screen!=='explore'){render();return;}
    var grid=host.querySelector('.genreGrid .grid');
    var top=grid?grid.scrollTop:0;
    var active=document.activeElement;
    var currentUrl=active&&active.getAttribute('data-series');
    var wasLoadMore=!!(active&&active.hasAttribute('data-next'));
    var selectedGenre=active&&active.getAttribute('data-genre');
    render();
    var nextGrid=host.querySelector('.genreGrid .grid');if(nextGrid)nextGrid.scrollTop=top;
    var target=wasLoadMore?host.querySelector('[data-next]'):
      currentUrl?Array.from(host.querySelectorAll('[data-series]')).find(function(el){return el.getAttribute('data-series')===currentUrl;}):
      selectedGenre?Array.from(host.querySelectorAll('[data-genre]')).find(function(el){return el.dataset.genre===selectedGenre;}):null;
    if(target)target.focus({preventScroll:true});
  }
  function loadCatalogPage(next){
    if(catalogLoading || catalogPage>=maxCatalogPage)return;
    catalogLoading=true;
    var page=catalogPage+1;
    fetchPage(SITE+'/catalogo?page='+page).then(function(doc){
      var records=readSeries(doc,SITE+'/catalogo?page='+page);
      if(!records.length){maxCatalogPage=page-1;return;}
      ALL=unique(ALL.concat(records));catalogPage=page;
      if(!popular.length)popular=records.slice(0,15);
      if(['explore','search','home'].indexOf(state.screen)>=0)renderCatalogPreservingScroll();
    }).catch(function(){/* retry on demand */}).finally(function(){catalogLoading=false;});
  }
  var localCache={};
  try{localCache=JSON.parse(localStorage.getItem('tf-meta-av1-v1')||'{}');}catch(e){}
  function cached(u){return localCache[u]||null;}
  function storeMeta(x){if(!x||!x.url)return;localCache[x.url]=x;
    try{var keys=Object.keys(localCache);if(keys.length>60)delete localCache[keys[0]];localStorage.setItem('tf-meta-av1-v1',JSON.stringify(localCache));}catch(e){}
  }
  function getArr(k){try{return JSON.parse(localStorage.getItem(k)||'[]');}catch(e){return [];}}
  function saveArr(k,a){try{localStorage.setItem(k,JSON.stringify(a.slice(0,90)));}catch(e){}}
  function saved(){return getArr('tftv-list');}
  function historyList(){return getArr('tftv-history');}
  function addHistory(item){saveArr('tftv-history',[item].concat(historyList().filter(function(v){return v.url!==item.url;})));}
  function toggleSaved(item){var a=saved(),present=a.some(function(v){return v.url===item.url;});saveArr('tftv-list',present?a.filter(function(v){return v.url!==item.url;}):[item].concat(a));}

  var viewport=document.querySelector('meta[name="viewport"]');
  if(!viewport){viewport=document.createElement('meta');viewport.name='viewport';document.head.appendChild(viewport);}
  viewport.setAttribute('content','width=1280,initial-scale=1.0');
  var css=document.createElement('style');css.id='tftv-css-v3';css.textContent=`
  #tftv,#tftv *{box-sizing:border-box}
  #tftv{position:fixed;inset:0;z-index:2147483647;display:flex;background:#090a0f;color:#f5f5f7;font:16px/1.4 Roboto,'Arial',sans-serif;overflow:hidden;letter-spacing:.03px}
  #tftv .rail{width:176px;flex:0 0 176px;border-right:1px solid #22252c;padding:15px 10px 10px;display:flex;flex-direction:column;gap:5px;background:#090a0f;overflow:hidden}
  #tftv .brand{display:flex;align-items:center;gap:10px;height:68px;min-height:68px;padding:0 8px;color:#fafafa;font-weight:800;font-size:16px;line-height:1.25}
  #tftv .brand img{width:44px;height:44px;object-fit:contain}#tftv .brand span b{display:block;color:#ff852d}
  #tftv button{cursor:pointer;font-family:inherit}#tftv button:focus,#tftv input:focus{outline:3px solid #ff9a37;outline-offset:1px;box-shadow:0 0 0 2px #5b341e;z-index:1}
  #tftv .nav{flex:0 0 42px;border:0;border-radius:8px;background:transparent;color:#c4c5cc;font-size:15px;font-weight:650;text-align:left;padding:0 12px;display:flex;align-items:center;gap:11px}
  #tftv .nav span{font-size:20px;width:27px;text-align:center}#tftv .nav.active{background:linear-gradient(90deg,#bd460f,#e56c10);color:#fff}
  #tftv .main{flex:1;min-width:0;overflow-y:auto;scrollbar-width:none;background:#090a0f;overscroll-behavior:contain}
  #tftv .main.explore-mode{height:100vh;overflow:hidden!important;display:flex;min-height:0}#tftv .main::-webkit-scrollbar,#tftv .posters::-webkit-scrollbar{display:none}
  #tftv .hero{position:relative;height:285px;display:flex;align-items:center;overflow:hidden;background:radial-gradient(ellipse at 70% 22%,#313b52,#090b11 65%)}
  #tftv .hero-image{position:absolute;right:0;top:0;width:67%;height:100%;object-fit:cover;object-position:center 32%;opacity:.80;mask-image:linear-gradient(to right,transparent 0%,#000 58%)}
  #tftv .hero-gradient{position:absolute;inset:0;background:linear-gradient(90deg,#090b10 1%,#0c0d14e8 36%,transparent 94%),linear-gradient(0deg,#090a0f 0%,transparent 28%)}
  #tftv .hero-text{position:relative;padding:12px 34px;max-width:590px;z-index:1}#tftv .hero h1{font-size:39px;line-height:1.08;font-weight:850;margin:0 0 9px;max-height:88px;overflow:hidden}
  #tftv .hero .genres{font-size:14px;color:#d5d5dd;font-weight:600;margin:0 0 9px}#tftv .hero .synopsis{font-size:16px;color:#e5e6e9;line-height:1.4;max-width:560px;max-height:66px;overflow:hidden;margin:0}
  #tftv .cta{padding:10px 21px;margin:14px 10px 0 0;background:#252832;color:#fff;border:1px solid #44454e;border-radius:7px;font-weight:750;font-size:15px}
  #tftv .cta.primary{background:#f07413;border-color:#f07413;color:#fff}
  #tftv .shelf{padding:2px 25px 7px}#tftv .shelf h2{font-size:21px;margin:10px 0 8px;font-weight:800}
  #tftv .posters{display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;padding:4px 2px 12px}
  #tftv .poster{flex:0 0 125px;max-width:125px;min-width:125px;background:transparent;border:0;color:#fafafa;text-align:left;padding:0}
  #tftv .poster .cover{display:block;width:125px;height:176px;object-fit:contain;object-position:center center;border-radius:7px;background:#191b25;overflow:hidden}
  #tftv .poster .caption{display:block;font-size:13px;font-weight:650;line-height:1.3;margin:6px 2px 0;max-height:34px;overflow:hidden}
  #tftv .recent-card{flex:0 0 220px;max-width:220px;text-align:left;padding:0;background:transparent;color:#f5f5f5;border:0}
  #tftv .recent-card img{width:220px;height:124px;object-fit:cover;border-radius:8px;background:#1d2029;display:block}
  #tftv .recent-card strong{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:7px}#tftv .recent-card small{display:block;color:#aaaeb8;font-size:12px;margin-top:1px}
  #tftv .heading{padding:23px 28px 5px;font-size:27px;font-weight:800}#tftv .explore-heading{font-size:25px;font-weight:850;flex:0 0 auto;padding:9px 14px 4px;margin:0}
  #tftv .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(122px,1fr));gap:16px 13px;padding:18px 30px 32px}
  #tftv .grid .poster{width:125px}#tftv .notice{font-size:15px;color:#b8bbc6;margin:20px 30px}
  #tftv .search{margin:12px 29px 0;background:#20232b;border:2px solid #444851;color:#fff;border-radius:9px;padding:14px 16px;width:80%;font-size:20px}
  #tftv .explore{display:grid;grid-template-columns:245px minmax(0,1fr);grid-template-rows:minmax(0,1fr);height:100%;min-height:0;width:100%;overflow:hidden}
  #tftv .genres-list{padding:10px 10px 16px 16px;max-height:100%;display:flex;flex-direction:column;gap:4px;height:100%;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-width:none;contain:layout paint}
  #tftv .genre{font-size:15px;font-weight:650;border:0;background:transparent;color:#dee0e7;padding:12px 15px;text-align:left;border-radius:5px;min-height:44px}
  #tftv .genre.active{background:#e87f20;color:#171113}#tftv .genreGrid{padding:0 8px 5px;display:grid;grid-template-rows:52px minmax(0,1fr);height:100%;max-height:100%;min-height:0;overflow:hidden}
  #tftv .genreGrid h2{font-size:21px;margin:13px 17px 4px}#tftv .genreGrid .grid{padding:10px 18px 26px;min-height:0;overflow-y:auto;overflow-x:hidden;align-content:start;overscroll-behavior:contain;scrollbar-width:none;contain:layout paint}
  #tftv .tabs{display:flex;gap:28px;padding:7px 30px 8px;border-bottom:1px solid #343841}#tftv .tab{font-size:16px;background:none;color:#cdd0da;border:0;padding:9px 5px;font-weight:800}
  #tftv .tab.active{border-bottom:3px solid #ff8e1c;color:#ff8e1c}
  #tftv .season-layout{display:grid;grid-template-columns:210px minmax(0,1fr);gap:17px;padding:15px 28px}
  #tftv .season-list{display:flex;flex-direction:column;align-self:start;gap:7px}
  #tftv .season-list .secttitle{font-size:16px;margin:0 0 6px;font-weight:700}
  #tftv .season{padding:12px 13px;text-align:left;border-radius:6px;color:#eee;border:1px solid #333741;background:#1b1d24;font-size:15px;font-weight:700}
  #tftv .season.active{background:#ba5415;border-color:#ff992f}
  #tftv .episode-list{display:flex;flex-direction:column;gap:8px;max-height:390px;overflow-y:auto;scrollbar-width:none;padding:1px 4px 18px}
  #tftv .episode-row{display:flex;align-items:center;gap:14px;background:#15171e;border:1px solid #30353e;color:#fff;padding:6px 10px;border-radius:8px;text-align:left;min-height:80px}
  #tftv .episode-pic{width:126px;height:70px;border-radius:5px;object-fit:cover;display:flex;flex:none;align-items:center;justify-content:center;background:linear-gradient(150deg,#2e3545,#13151d);font-size:18px;font-weight:800;color:#bfc3cd}
  #tftv .episode-row strong{font-size:16px;font-weight:750;display:block}#tftv .episode-row small{font-size:12px;color:#afb0b9;display:block;margin-top:6px}
  #tftv .detail-p{margin:18px 30px;font-size:18px;max-width:850px;color:#d4d6dd;line-height:1.65}
  #tftv.detail-mode .rail{display:none}#tftv.detail-mode .main{width:100%;overflow-y:auto}
  #tftv.detail-mode .hero{height:78vh;min-height:480px;align-items:flex-end}
  #tftv.detail-mode .hero-image{width:100%;object-position:center 30%;opacity:1;mask-image:none}
  #tftv.detail-mode .hero-gradient{background:linear-gradient(90deg,#090a10 0%,#090a10df 23%,transparent 77%),linear-gradient(0deg,#090a0f 0%,transparent 55%)}
  #tftv.detail-mode .hero-text{padding:0 45px 90px;max-width:640px}
  #tftv.detail-mode .hero h1{font-size:47px;max-height:120px}
  #tftv .detail-header{position:fixed;top:12px;left:30px;z-index:4;display:flex;gap:14px;align-items:center}
  #tftv .detail-back{font:700 17px Roboto,Arial;border:1px solid #555;padding:11px 18px;border-radius:7px;background:#141722d9;color:white}
  #tftv.detail-mode .tabs{position:sticky;top:0;z-index:2;background:#090a0f;padding-top:14px}
  #tftv .season-layout{min-height:450px}
  #tftv .episode-list{max-height:none}
  #tftv .episode-row{height:91px;min-height:91px;max-height:91px;overflow:hidden;align-items:center}
  #tftv .episode-row>span:last-child{display:block;flex:1;min-width:0;max-height:72px;overflow:hidden}
  #tftv .episode-row strong{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;font-size:16px;line-height:1.3;overflow-wrap:break-word}
  #tftv .episode-row small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  @media(max-height:620px){#tftv .rail{padding-top:7px}#tftv .brand{height:51px;min-height:51px}#tftv .nav{flex-basis:37px}#tftv .hero{height:240px}#tftv .episode-list{max-height:260px}#tftv .poster .cover{height:160px}}
  `;
  document.head.appendChild(css);
  var host=document.createElement('div');host.id='tftv';document.body.appendChild(host);
  document.documentElement.style.overflow='hidden';document.body.style.overflow='hidden';

  var nav=[['home','⌂','Inicio'],['search','⌕','Buscar'],['explore','▤','Explorar'],['list','▱','Mi lista'],['history','◷','Historial'],['profile','♙','Perfil'],['settings','⚙','Ajustes']];
  var brandSvg='<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wAARCABIAEgDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAMEBQcBAgYI/8QAOxAAAgEDAQUFBQQJBQAAAAAAAQIDBAURAAYSITFBEyJRYXEHFDJCgZGSobEVIzM0UlNyc4JissHR8P/EABsBAAMAAwEBAAAAAAAAAAAAAAQFBgACAwEH/8QALhEAAQIEBQIEBwEBAAAAAAAAAQIDAAQRIQUxQVFxEoEGE5GxFCJhodHw8SMy/9oADAMBAAIRAxEAPwDzpZ7OK9Zqqpn91oKbHbT7u8cn4URfmdsHA5cCSQATp7+kYoGKWymWii5Byd+ZvNnx+CgDy02uM/ZJBbYm/U0o4gcmmYDfb8lHko1L2jZ17lsnc7nCjST0kyHA6RhSX/3A+i63C0NpDjupAHfKO5accWpprMAk9hUwxSslJyZpCepLHS4rpMftH+8dRPaY66yJc8AdMw7SFRbqYk2r5f5j/eOm8lbJ/Mf7x02KTGQRCKQyE4CBSWJ8MamZfZ/tglCK59mLytOcYc0rZ48u7je/DXJ2aQinUoCv1jdLBrSkRDV0ynKyup8Qx0R3SNzuV8IqYzzcYWVfMN19DkaL1YbzYOzF2tVfbzKMx+8wNHv+mRx1FEk5xk446GUtDoqLiCWlLaPymkSl4s60Iinp51qqOoXfhnUY3gOasPldTwK9OHMEEmkrXcG92qbZJ3oajEiA/JKo4MPDIyp8cjwGjQnUUHpVDFLXmgLSOeYbyEtK7E5JYn8dW7sFTSWBY4ixkoLrFHUU0+O6Jdzvwt03scR/EB6jVROe+3qfz1aGw19morPTW66IiUs65pJZOMVSu9nczy31bPDgR06HQeNhRl6JuNR96jinpWGPhrp+NuaK0rkdKHkGx3pxCW1XsqqJpKq47Lx+8wRx9tLQICZYuPe7MfOoznHMDI44zquqeWCGcGqp2nhHB0WTcb6HBwfUHV+2+/xUF1p56WdqF1JBEuWjbyJ5gHl1xwPHTjbHZXZja8tU1lAKepfi9XSEJOp/1cN2Qf1DPmNIZTxKtkhmbBKTkoZjnfkGsOcY8IrQ95kmM79J32Gkcn7PtrLTSzQU1poZRWSndRpKoyzhevH4Yx9M67jbC5RbI0M1+oLfDJdkhJNZIC5iGDyJPxHjjyyfLVaUOw102CvKXWjnhulqDAPVxrutCflEqHimSfiBKnHPpq5tk0o9qLb+hbjEJS2WBflIM5P14kY8DqfxtTLb6Zls9betzcag8bH2hzKhS5EOvIopBII22J3Az/keU71tJdto6l6i6V9RVO7b2HclVPkvIa7/AGH2GMPs72m2qukO4tRQSU9vD/MB3nlHllQoPXvakbx7GqPY/buSjuUpqbWw95olc7olizgh26lDwIHPIPXVg3tIL9aILdUMKa1qESaBe67wpgiJQPhDYGW6KCBxPB5iOOtFppqTsg0JIFKAXoBvofTiWksCmX0GcevWtL1JOV9hXf2jzDSk+9RHrvj89GnVZPDV7QTT06IkMtWzxogwqqX4ADoMY0aqXlV6SRpC7D2zRQG8Iu3fb1Ouk2S2x/QaS0NchqLdMd5o2UOFbx3TwI/8Ncs799vU/nrG9w0Q+yh9vy3BaAJSbclHvOazG9wRsRqDFuNfbVVU4kpnpCo+AJIRu/4k/hjT+n2tpZ4lhcCmbGAB+z+hzwHlqnqW7S0zBikchXkzKMj66ey7R1dWm68iKvhnj9gGpx7A6mmY3rH0eW8YS60AqTRQ0At729TFu2zalYaoUxfcZwVU81dTwIPiD4HVj+znskmdFQdmZVkh8UbdOQD9MemvPWx2zt4ud0pXjR1iWQSFGGMKOZI6Z5avqiqYbHSEdruCmU9s4HJm5/XHADn9upHH5VtseS0ak7Q2VMqnZZRLZQVe2h9co19sNwjqaO21avCJqa4hIXlOF3GjkDZPh3VP+I1V+0V1hhsc9RX3KcpMGGIl3JKgn5ASTug9SATjw0w9pW38F0uFNb2d3ioy0sqxgH9a2QEzy7icCf4mbw1XN1uUl0qe1bfVFG6iPIXKj1P/ABgaeYFgS0sthy1L9q5d84l5nGWZOWdl2j1EkgAH6AE2+oyqK8QjR/vsH91eXqNGsUf75B/cX8xo1WzWYidwj/hXMaTqY5pEb4lYg/brTOpi82yR6dLvAhaCQiOYgcI5cdfDeAyPPI6ahwM6IacC01EKZlktOFJ7caQ4ovdhOHqxI0S8THGcNIeig9PM+GrP2OtFM9LRV9VTUoqK4n3G3wpu4UfOxPFuAzvMSAPMjVWqh12OyO1fue01DVXBt2njphRK3SFQAAfTIyfU6W4vLuusktaA/wAHPrS0OMBnW5d4ddBUgV5OZ4GQyrfSLuvVwo9hrSkNEkKVT57SbAGGAy7DPRc/EeXAc9UttZ7Qq+5we70czU9KSSm7kPJ4uTzGfHmfLT72r3ypq7mlIHJgami3XU8HTeZjx65bGf6Rqv2TPE8dKMBwVCW0zD11G9/3+Q3xvHXG1LlWje9TrX8U99s2wGs40qya1K6roiY3oFL11OBz7Rfz0albXbjS0El1qFKh96KlB5u3J3Hko4Z8T5HRoF7/AEV8ukPpBYl26rF1X7QvZr3LbO1QKksE6dnPBKMxzJnO6w9QCDzBAIIOm1XbaOVzJQyGJTx7GY53fIN1HqNGjWKHQrrTYxq3R1AQ4K+4hBaKRei/eGlUoZG5bg9XGjRr0zKgIxOGNE0qf3tCrUFQyqGkQqvBQZVwvoM8NJGgkH8v76/96NGtUzSthHZWEtbn7fiE3opM47n3hpekpKGnYS1hNTg5ECEqp/qbnjyH2jRo1uXVLtlxA/wjbJ6gK8xtd7xPc5A0pUKiiONEG6kaDkqgcAB4aNGjXVCAkUECPOqWqqjH/9k=" alt="Fénix">';
  function imgTag(src,cls,alt){return src?'<img class="'+(cls||'')+'" src="'+esc(src)+'" alt="'+esc(alt||'')+'" loading="lazy" onerror="this.style.opacity=0.12">':'<div class="'+(cls||'')+'" style="background:#202330"></div>';}
  function card(x){return '<button class="poster" data-series="'+esc(x.url)+'">'+imgTag(x.img,'cover',x.title)+'<span class="caption">'+esc(x.title)+'</span></button>';}
  function shelf(title,items){if(!items||!items.length)return '';return '<section class="shelf"><h2>'+esc(title)+'</h2><div class="posters">'+items.map(card).join('')+'</div></section>';}
  function navHTML(){return '<aside class="rail"><div class="brand">'+brandSvg+'<span>Toki Lite<b>Fénix TV</b></span></div>'+nav.map(function(n){return '<button class="nav '+(state.screen===n[0]?'active':'')+'" data-nav="'+n[0]+'"><span>'+n[1]+'</span>'+n[2]+'</button>';}).join('')+'</aside>';}
  function heroHTML(x,detail){
    var meta=cached(x.url)||x;var synopsis=meta.description||'';
    return '<section class="hero">'+(meta.banner||meta.img?imgTag(meta.banner||meta.img,'hero-image',''):'')+'<div class="hero-gradient"></div><div class="hero-text"><h1>'+esc(meta.title||x.title)+'</h1><p class="genres">'+esc(meta.genre||'Anime · Serie · Subtitulado')+'</p><p class="synopsis">'+esc(synopsis||'Selecciona el título para consultar la sinopsis y sus episodios.')+'</p><button class="cta primary" '+(detail?'data-playfirst="1"':'data-series="'+esc(x.url)+'"')+'>▶ '+(detail?'Reproducir':'Ver ahora')+'</button><button class="cta" data-save="'+esc(x.url)+'">＋ Mi lista</button></div></section>';
  }
  function recentShelf(){if(!RECENT.length)return '';
    return '<section class="shelf"><h2>Episodios recientes</h2><div class="posters">'+RECENT.slice(0,16).map(function(r){
      return '<button class="recent-card" data-recent="'+esc(r.url)+'">'+imgTag(r.img,'',r.title)+'<strong>'+esc(r.title)+'</strong><small>Episodio '+r.number+' · Subtitulado</small></button>';
    }).join('')+'</div></section>';
  }
  function renderHome(){var hero=popular[0]||ALL[0];if(!hero)return '<section class="shelf" style="padding-top:100px"><h1 class="heading">Toki Lite Fénix TV</h1><p class="notice">Preparando el catálogo. Si AnimeAV1 no responde, pulsa Reintentar.</p><button class="cta primary" data-refresh="1">↻ Reintentar</button></section>';
    return heroHTML(hero,false)+shelf('Populares',popular.slice(0,15))+recentShelf()+SECTIONS.map(function(s){return shelf(s.title,s.items);}).join('');
  }
  function grid(title,items){return '<h1 class="heading">'+esc(title)+'</h1>'+(items.length?'<div class="grid">'+items.map(card).join('')+'</div>':'<p class="notice">No hay resultados disponibles.</p>');}
  function renderExplore(){var genre=GENRES.find(function(g){return g[1]===state.selectedGenre;})||GENRES[0];
    var list=state.selectedGenre==='popular'?popular:state.selectedGenre==='recientes'?ALL:state.selectedGenre==='todos'?ALL:state.selectedGenre==='az'?ALL.slice().sort(function(a,b){return a.title.localeCompare(b.title);}):state.genreResults;
    return '<div class="explore"><div class="genres-list"><h1 class="explore-heading">EXPLORAR</h1>'+GENRES.map(function(g){return '<button class="genre '+(g[1]===state.selectedGenre?'active':'')+'" data-genre="'+g[1]+'">'+esc(g[0])+'</button>';}).join('')+'</div><div class="genreGrid"><h2>'+esc(genre[0])+'</h2>'+(state.busy&&!list.length?'<p class="notice">Cargando títulos…</p>':'<div class="grid">'+list.map(card).join('')+(!state.genreNoMore&&state.selectedGenre!=='popular'?'<button class="cta load-more" data-next="1">＋ Cargar más animes</button>':'')+'</div>')+'</div></div>';
  }
  function renderSearch(){var hits=state.search?ALL.filter(function(x){return lower(x.title).indexOf(lower(state.search))!==-1;}):popular;
    return '<h1 class="heading">Buscar anime</h1><input id="tf-search" class="search" value="'+esc(state.search)+'" placeholder="Buscar por título…"/>'+grid('Resultados',hits.slice(0,60));}
  function seasonEntries(){return state.seasons.length?state.seasons:[{title:'Temporada 1',url:state.series.url}];}
  function renderDetail(){var x=state.series||popular[0],meta=cached(x.url)||x;
    var tabs='<div class="tabs"><button class="tab '+(state.tab==='episodes'?'active':'')+'" data-tab="episodes">EPISODIOS</button><button class="tab '+(state.tab==='details'?'active':'')+'" data-tab="details">DETALLES</button><button class="tab '+(state.tab==='similar'?'active':'')+'" data-tab="similar">COSAS SIMILARES</button></div>';
    var body='';
    if(state.tab==='episodes'){
      body='<div class="season-layout"><div class="season-list"><div class="secttitle">Temporadas</div>'+seasonEntries().map(function(s,i){return '<button class="season '+(state.season===i?'active':'')+'" data-season="'+i+'">'+esc(s.title)+'</button>';}).join('')+'</div><div class="episode-list" id="tf-episodes">'+(state.busy?'<p class="notice">Cargando capítulos…</p>':state.episodes.length?state.episodes.map(function(ep,i){
        var n=ep.number||i+1;var label=ep.title.replace(/^ep(?:isodio)?\s*\d+\s*[·–-]?/i,'').trim();
        if(/^episodio\s*\d+$/i.test(label))label='';
        return '<button class="episode-row" data-watch="'+i+'">'+(ep.img?imgTag(ep.img,'episode-pic',''):'<span class="episode-pic">EP '+n+'</span>')+'<span><strong>Episodio '+n+(label?' · '+esc(label):'')+'</strong><small>OK para reproducir</small></span></button>';
      }).join(''):'<p class="notice">No se encontraron episodios. Puedes reintentar al volver a abrir la ficha.</p>')+'</div></div>';
    }else if(state.tab==='details')body='<p class="detail-p">'+esc(meta.description||'Sinopsis no disponible.')+'</p>';
    else body=shelf('Recomendaciones',popular.filter(function(v){return v.url!==x.url;}).slice(0,12));
    return '<div class="detail-header"><button class="detail-back" data-nav="home">← Regresar</button><strong>Toki Lite Fénix TV</strong></div>'+heroHTML(meta,true)+tabs+body;
  }
  function render(){var html='';switch(state.screen){
    case 'home':html=renderHome();break;
    case 'explore':html=renderExplore();break;
    case 'search':html=renderSearch();break;
    case 'detail':html=renderDetail();break;
    case 'list':html=grid('Mi lista',saved());break;
    case 'history':html=grid('Historial local',historyList());break;
    case 'profile':html='<h1 class="heading">Perfil</h1><p class="notice">Mi lista e historial local. Para sincronización necesitas iniciar sesión en el sitio y que Toki admita esa función.</p><button class="cta primary" data-login="1">Sincronización (no disponible)</button>';break;
    case 'settings':html='<h1 class="heading">Ajustes</h1><p class="notice">Toki Lite Fénix TV · Adaptador AnimeAV1 v9.4 · Control remoto: flechas, OK y Atrás.</p><p class="notice">No añade SDK de publicidad ni telemetría. El filtrado de contenido del sitio no es absoluto.</p><button class="cta" data-reload="1">Actualizar catálogo</button>';break;
  }
    host.className=state.screen==='detail'?'detail-mode':'';host.innerHTML=navHTML()+'<main class="main '+(state.screen==='explore'?'explore-mode':'')+'" id="tf-main">'+html+'</main>';bind();
    var focus=host.querySelector(state.screen==='detail'?'.detail-back':'.nav.active');if(focus)focus.focus({preventScroll:true});
  }
  function navigate(name){state.screen=name;render();if(name==='home')loadHero();}
  function findByUrl(u){return ALL.concat(popular,saved(),historyList()).find(function(x){return x.url===u;})||null;}
  function fetchPage(u){return fetch(u,{credentials:'include'}).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.text();}).then(function(h){return new DOMParser().parseFromString(h,'text/html');});}
  function parseDetails(doc,item){
    var ogDesc=doc.querySelector('meta[property="og:description"],meta[name="description"]');
    var paragraphs=Array.from(doc.querySelectorAll('p')).map(txt).filter(function(t){
      return t.length>80&&t.length<2200&&!/pol[ií]tica de privacidad|t[eé]rminos y condiciones|By fans for fans|comentarios|copyright/i.test(t);
    });
    var desc=(ogDesc&&ogDesc.getAttribute('content'))||paragraphs[0]||item.description||'';
    var backdrop=Array.from(doc.images).find(function(i){return /backdrop|fondo/i.test(i.alt||'')});
    var poster=Array.from(doc.images).find(function(i){return /p[oó]ster|portada/i.test(i.alt||'')});
    var ogImg=doc.querySelector('meta[property="og:image"]');
    var banner=getImg(backdrop,item.url)||url(ogImg&&ogImg.content,item.url)||item.banner||item.img;
    var img=getImg(poster,item.url)||item.img||banner;
    var genre=Array.from(doc.querySelectorAll('a[href*="/catalogo?genre="]')).map(txt).filter(function(t){return t.length>2&&t.length<24;});
    return {url:item.url,title:item.title,img:img,banner:banner,description:desc,genre:genre.slice(0,4).join(' · ')||'Anime · Serie'};
  }
  function getEpisodes(doc,base){
    var parentSlug=(new URL(base)).pathname.split('/').filter(Boolean).pop();
    var seen={};
    return Array.from(doc.querySelectorAll('a[href]')).map(function(a){
      var dest=url(a.getAttribute('href'),base);
      if(!watchUrl(dest)||seen[dest])return null;
      var watchSlug=(new URL(dest)).pathname.split('/').filter(Boolean)[1];
      if(watchSlug!==parentSlug)return null;
      seen[dest]=true;
      var number=Number((dest.match(/\/(\d+)\/?$/)||[])[1]||0);
      var label=txt(a).replace(/viendo ahora|siguiente|con video/gi,'').trim();
      return {url:dest,title:label||'Episodio '+number,number:number,img:getImg(a.querySelector('img'),base)};
    }).filter(Boolean).sort(function(a,b){return a.number-b.number;}).slice(0,600);
  }
  // A season must belong to this same franchise. A recommendation containing
  // "Season 2" is not evidence for the current anime. Never mix catalogs.
  function franchiseStem(slug){
    return slug.replace(/(?:-?(?:2nd|3rd|4th|5th)-season|-season-?[2-9]|-temporada-?[2-9]|-s[2-9])$/i,'');
  }
  function getSeasons(doc,current){
    // AnimeAV1 catalog often represents subsequent seasons as separate media
    // entries. Do not infer season links from the Related list.
    var n=1;
    var t=current.title||'';
    var match=t.match(/(?:season|temporada)\s*([2-9])/i);
    if(match)n=Number(match[1]);
    else {var ordinal=t.match(/\b(2nd|3rd|4th|5th)\s+season/i);
      if(ordinal)n={'2nd':2,'3rd':3,'4th':4,'5th':5}[ordinal[1].toLowerCase()];}
    return [{title:'Temporada '+n,url:current.url}];
  }
  function loadHero(){var feature=popular[0]||ALL[0];if(!feature)return;
    if(cached(feature.url)){if(state.screen==='home')render();return;}
    fetchPage(feature.url).then(function(d){storeMeta(parseDetails(d,feature));if(state.screen==='home')render();}).catch(function(){});
  }
  function openSeries(item){if(!item)return;state.series=item;state.screen='detail';state.seasons=getSeasons(null,item);state.season=0;state.episodes=[];state.tab='episodes';state.busy=true;render();
    fetchPage(item.url).then(function(doc){if(!state.series||state.series.url!==item.url)return;
      var meta=parseDetails(doc,item);storeMeta(meta);state.series=meta;
      state.episodes=getEpisodes(doc,item.url);state.seasons=getSeasons(doc,item);state.busy=false;render();
    }).catch(function(){state.busy=false;render();});
  }
  function selectSeason(i){var seasons=seasonEntries();var selected=seasons[i];if(!selected)return;
    state.season=i;
    if(selected.url!==state.series.url){state.busy=true;state.episodes=[];render();fetchPage(selected.url).then(function(d){state.episodes=getEpisodes(d,selected.url);state.busy=false;render();focusEpisode();}).catch(function(){state.busy=false;render();focusEpisode();});}
    else {render();focusEpisode();}
  }
  function focusEpisode(){var el=host.querySelector('.episode-row');if(el){el.focus({preventScroll:true});el.scrollIntoView({block:'nearest'});}}
  function selectGenre(slug){
    state.selectedGenre=slug;state.genreResults=[];state.genrePage=0;state.genreNoMore=false;state.busy=false;
    if(['popular','recientes','az','todos'].indexOf(slug)>=0){render();return;}
    state.busy=true;render();loadMoreGenre();
  }
  function loadMoreGenre(){
    var slug=state.selectedGenre;
    if(['popular','recientes','az','todos'].indexOf(slug)>=0){loadCatalogPage(true);return;}
    if(state.genreNoMore)return;
    var page=state.genrePage+1;state.busy=true;
    var target=SITE+'/catalogo?genre='+encodeURIComponent(slug)+'&page='+page;
    fetchPage(target).then(function(doc){
      if(state.selectedGenre!==slug)return;
      var records=readSeries(doc,target);
      state.genreResults=unique(state.genreResults.concat(records));
      state.genrePage=page;
      state.genreNoMore=records.length===0||page>=50;
      ALL=unique(ALL.concat(records));
    }).catch(function(){/* keep retry button visible */})
      .finally(function(){if(state.selectedGenre===slug){state.busy=false;renderCatalogPreservingScroll();}});
  }
  function directSource(doc,base){
    // Only accept explicit, HTTPS media references exposed by the website.
    // Never extract DRM keys, bypass embed restrictions or fabricate stream URLs.
    var sources=Array.from(doc.querySelectorAll('video[src],video source[src]'));
    for(var i=0;i<sources.length;i++){
      var src=url(sources[i].getAttribute('src'),base);
      if(/^https:\/\//.test(src)&&/\.(?:mp4|webm|m3u8)(?:[?#]|$)/i.test(src))return src;
    }
    return '';
  }
  function noSourcePlayer(item){
    var overlay=document.createElement('div');overlay.id='tf-direct-player';
    overlay.style.cssText='position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:#08090e;color:#fff;font:20px Roboto,Arial,sans-serif';
    overlay.innerHTML='<section style="max-width:750px;padding:30px;text-align:center"><h1 style="font-size:32px">Reproductor Fénix</h1><p>No encontramos una fuente MP4, WebM o HLS publicada directamente para este episodio. La reproducción automática no está disponible para este servidor.</p><p style="color:#a4a6b1;font-size:16px">No se abrirán páginas ni anuncios externos.</p><button data-direct="back" style="padding:18px 35px;background:#f57b1a;color:#111;border:0;border-radius:9px;font-weight:bold;font-size:20px">← Volver al anime</button></section>';
    host.appendChild(overlay);
    overlay.querySelector('[data-direct=back]').onclick=stopDirectPlayer;
    overlay.querySelector('[data-direct=back]').focus();
  }
  function stopDirectPlayer(){
    var overlay=host.querySelector('#tf-direct-player');
    if(!overlay)return false;
    var video=overlay.querySelector('video');if(video){video.pause();video.removeAttribute('src');video.load();}
    overlay.remove();try{if(window.TokiNative)window.TokiNative.cancelResolve();}catch(e){}return true;
  }
  // Native Fire TV builds never show a browser-based video element.
  // Playback is routed to NativePlayerActivity after resolving an authorized
  // direct MP4/HLS/DASH media source. Browser previews display a clear error.
  function showDirectPlayer(src,item){
    noSourcePlayer(item);
  }
  // v8: use the native resolver/Media3 player. Never navigate into a web player.
  // The native player is a separate Android Activity. Remove its loading
  // overlay when it opens AND when it returns to the catalog.
  window.__tokiTVPlayerOpened=function(){
    var overlay=host&&host.querySelector('#tf-direct-player');
    if(overlay)overlay.remove();
  };
  window.__tokiTVPlayerReturned=function(){
    var overlay=host&&host.querySelector('#tf-direct-player');
    if(overlay && /Comprobando la fuente/.test(overlay.textContent))overlay.remove();
    var focused=host&&host.querySelector('.episode-row');
    if(focused && !host.contains(document.activeElement))focused.focus();
  };
  window.__tokiTVPlayerError=function(reason){
    stopDirectPlayer();
    var overlay=document.createElement('div');overlay.id='tf-direct-player';
    overlay.style.cssText='position:fixed;inset:0;background:#090a0f;z-index:99999;display:flex;align-items:center;justify-content:center;color:#fff;font:19px Roboto,Arial,sans-serif';
    var panel=document.createElement('div');panel.style.cssText='width:min(75vw,750px);padding:32px;text-align:center;background:#171923;border-radius:20px';
    var title=document.createElement('h2');title.textContent='Reproductor Fénix';panel.appendChild(title);
    var message=document.createElement('p');message.textContent=reason||'La fuente no se pudo resolver';panel.appendChild(message);
    var close=document.createElement('button');close.textContent='← Volver a episodios';close.style.cssText='padding:16px 28px;background:#f58a24;color:#121212;border:0;border-radius:10px;font-size:20px;font-weight:700';
    close.onclick=stopDirectPlayer;panel.appendChild(close);overlay.appendChild(panel);host.appendChild(overlay);close.focus();
  };
  function openWatch(item){
    if(!item||!watchUrl(item.url))return;
    if(state.series)addHistory(state.series);
    try{sessionStorage.setItem('tftv-restore',JSON.stringify(state.series));}catch(e){}
    if(window.TokiNative && typeof window.TokiNative.requestEpisode === 'function') {
      var oldOverlay=host.querySelector('#tf-direct-player');if(oldOverlay)oldOverlay.remove();
      var overlay=document.createElement('div');overlay.id='tf-direct-player';
      overlay.style.cssText='position:fixed;inset:0;z-index:99999;background:#080a10;display:flex;align-items:center;justify-content:center;color:#fff;font:22px Roboto,Arial,sans-serif';
      overlay.innerHTML='<section style="text-align:center"><h1>Reproductor Fénix</h1><p>Comprobando la fuente de vídeo...</p><button data-direct="back" style="background:#f47e20;border:0;border-radius:9px;padding:16px 26px;font-size:19px">← Volver</button></section>';
      host.appendChild(overlay);overlay.querySelector('button').onclick=stopDirectPlayer;overlay.querySelector('button').focus();
      window.TokiNative.requestEpisode(item.url, (state.series ? state.series.title : 'Anime')+' · Episodio '+(item.number||''));
      return;
    }
    // No native bridge exists in browser-only previews. Do not open any
    // third-party playback pages or inject a web video player.
    noSourcePlayer(item);
  }
  document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible'){
    var overlay=host&&host.querySelector('#tf-direct-player');
    if(overlay && /Comprobando la fuente/.test(overlay.textContent))stopDirectPlayer();
  }});
  function playFirst(){if(state.episodes.length)openWatch(state.episodes[0]);else {var a=host.querySelector('.season.active');if(a)a.focus();}}
  function bind(){
    host.querySelectorAll('[data-nav]').forEach(function(b){b.onclick=function(){navigate(b.dataset.nav);};});
    host.querySelectorAll('[data-series]').forEach(function(b){b.onclick=function(){openSeries(findByUrl(b.dataset.series));};});
    host.querySelectorAll('[data-save]').forEach(function(b){b.onclick=function(){var x=findByUrl(b.dataset.save)||state.series;if(x){toggleSaved(x);render();}};});
    host.querySelectorAll('[data-tab]').forEach(function(b){b.onclick=function(){state.tab=b.dataset.tab;render();var t=host.querySelector('[data-tab="'+state.tab+'"]');if(t)t.focus();};});
    host.querySelectorAll('[data-season]').forEach(function(b){b.onclick=function(){selectSeason(+b.dataset.season);};});
    host.querySelectorAll('[data-watch]').forEach(function(b){b.onclick=function(){openWatch(state.episodes[+b.dataset.watch]);};});
    host.querySelectorAll('[data-playfirst]').forEach(function(b){b.onclick=playFirst;});
    host.querySelectorAll('[data-recent]').forEach(function(b){b.onclick=function(){openWatch({url:b.dataset.recent});};});
    host.querySelectorAll('[data-genre]').forEach(function(b){b.onclick=function(){selectGenre(b.dataset.genre);};});
    var input=host.querySelector('#tf-search');if(input)input.oninput=function(){state.search=this.value;var pos=this.selectionStart;render();var i=host.querySelector('#tf-search');if(i){i.focus();try{i.setSelectionRange(pos,pos);}catch(e){}}};
    var next=host.querySelector('[data-next]');if(next)next.onclick=function(){loadMoreGenre();};
    var reload=host.querySelector('[data-reload]');if(reload)reload.onclick=loadCatalog;
    var refresh=host.querySelector('[data-refresh]');if(refresh)refresh.onclick=loadCatalog;
    var login=host.querySelector('[data-login]');if(login)login.onclick=function(){alert('El inicio de sesión remoto de AnimeAV1 aún no está integrado. Tus favoritos e historial se guardan localmente.');};
  }
  function directional(key){
    var active=document.activeElement;if(!host.contains(active))active=host.querySelector('.nav.active');
    if(!active)return;
    // Explore is two completely separate vertical viewports; never move either
    // viewport when focusing an element in the other one.
    if(state.screen==='explore'){
      if(key==='ArrowRight'&&active.closest('.genres-list')){
        var first=host.querySelector('.genreGrid .poster');if(first){first.focus();first.scrollIntoView({block:'nearest',inline:'nearest'});}return;
      }
      if(key==='ArrowLeft'&&active.closest('.genreGrid')){
        var selected=host.querySelector('.genre.active');if(selected){selected.focus();selected.scrollIntoView({block:'nearest'});}return;
      }
    }
    var container=active.closest('.genres-list,.genreGrid .grid,.posters,.episode-list,.rail');
    var same=Array.from((container||host).querySelectorAll('button,input')).filter(function(e){return e.getClientRects().length>0;});
    var horizontal=key==='ArrowLeft'||key==='ArrowRight';
    var b=active.getBoundingClientRect(),cx=(b.left+b.right)/2,cy=(b.top+b.bottom)/2;
    function pick(items){var best=null,score=Infinity;
      items.forEach(function(el){if(el===active)return;var r=el.getBoundingClientRect();
        var dx=(r.left+r.right)/2-cx,dy=(r.top+r.bottom)/2-cy;
        if((key==='ArrowLeft'&&dx>=-8)||(key==='ArrowRight'&&dx<=8)||(key==='ArrowUp'&&dy>=-8)||(key==='ArrowDown'&&dy<=8))return;
        var dist=horizontal?Math.abs(dx)+Math.abs(dy)*2.8:Math.abs(dy)+Math.abs(dx)*2.8;
        if(dist<score){score=dist;best=el;}
      });return best;
    }
    var best=pick(same);
    if(!best&&!(state.screen==='explore'&&(container&&container.classList.contains('grid')||container&&container.classList.contains('genres-list'))))best=pick(Array.from(host.querySelectorAll('button,input')).filter(function(e){return e.getClientRects().length>0;}));
    if(best){best.focus({preventScroll:true});best.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});}
  }
  window.__tokiTVBack=function(){
    if(stopDirectPlayer())return;
    if(host.style.display==='none'){host.style.display='flex';document.body.style.overflow='hidden';render();return;}
    if(state.screen==='detail'){navigate('home');return;}
    if(state.screen!=='home'){navigate('home');return;}
  };
  document.addEventListener('keydown',function(e){
    if(host.style.display==='none')return;
    if(['Escape','Backspace','BrowserBack'].indexOf(e.key)>=0){e.preventDefault();window.__tokiTVBack();return;}
    if(host.querySelector('#tf-direct-player'))return;
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].indexOf(e.key)>=0){if(document.activeElement&&document.activeElement.tagName==='INPUT')return;e.preventDefault();directional(e.key);return;}
    if((e.key==='Enter'||e.key===' ')&&host.contains(document.activeElement)&&document.activeElement.tagName!=='INPUT'){e.preventDefault();document.activeElement.click();}
  },true);
  render();loadCatalog();
  try{var savedSeries=sessionStorage.getItem('tftv-restore');if(savedSeries){sessionStorage.removeItem('tftv-restore');var s=JSON.parse(savedSeries);if(s&&seriesUrl(s.url))openSeries(s);}}catch(e){}
})();
