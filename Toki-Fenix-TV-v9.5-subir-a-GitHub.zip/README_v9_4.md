# Toki Lite Fénix TV v9.4 — Adaptación del catálogo de AnimeAV1

Proyecto Android TV para Fire OS 8 / Fire TV Stick 4K Max (2.ª generación). La **interfaz Fénix permanece local** y está optimizada para control remoto; no muestra el diseño de la web como interfaz principal.

## Integrado en v9.4

- Catálogo público de `https://animeav1.com/` y `/catalogo`, en lugar del catálogo de Toki.
- Exploración progresiva del catálogo mediante `/catalogo?page=N` (hasta la última página disponible) y filtros `/catalogo?genre=...&page=N`. `Cargar más animes` permite avanzar con el control.
- Series con URLs `/media/<slug>` y episodios `/media/<slug>/<n>`. Se comprueba que el slug del episodio coincida exactamente con el de la serie para evitar mezclar capítulos de otras series.
- Temporadas: sólo la temporada documentada en la ficha. Las continuaciones independientes (por ejemplo, `2nd Season`) se presentan inicialmente como fichas separadas. No se inventan vínculos entre recomendaciones y temporadas.
- Portadas: reconocimiento de atributos de imagen `Portada de`, `Póster de` y `Backdrop`; preferencia por ilustraciones de banner en la ficha, sin estirar las miniaturas pequeñas.
- Reproductor nativo **Media3/ExoPlayer**, sin SDK propio de anuncios ni telemetría, con controles de TV y selector de pistas si el stream las proporciona. Resolución real del vídeo mediante `Player.Listener.onVideoSizeChanged`; nunca se anuncia un 1080p no verificado.
- Se mantiene la navegación con control remoto, favoritos e historial **locales**, y la apariencia oscura/naranja original.

## Limitaciones importantes

- **No se ha generado ni probado una APK v9.4 en un Fire Stick real.** Se requiere JDK 17, Android SDK 35, Gradle y conexión a Google Maven para compilar las dependencias de Media3. La compilación automatizada está en `.github/workflows/android-apk.yml`.
- **No se ha verificado la reproducción real de ningún episodio de AnimeAV1 en Media3.** La pantalla de episodio y la URL del vídeo son conceptos distintos: los servidores externos podrían requerir un reproductor web o permisos que la aplicación no puede omitir.
- El catálogo de AnimeAV1 anuncia 1.000 resultados distribuidos en aproximadamente 50 páginas (consultado noviembre de 2026). La app **no descarga las 50 páginas de golpe**. Se cargan progresivamente al seleccionar «Cargar más»; si un proveedor cambia la estructura HTML, el extractor necesitará actualización.
- Las fichas de series largas pueden mostrar inicialmente sólo los episodios publicados en el HTML del primer bloque (p. ej., 1-50); la navegación dinámica de bloques adicionales no está implementada ni probada.
- Los usuarios y listas de Toki o AnimeAV1 **no están sincronizados**: Mi lista e Historial son locales. La distribución y uso de datos, portadas y contenidos están sujetos a derechos y condiciones aplicables.
- Esta versión **no evade DRM, CAPTCHA, comprobaciones de acceso ni sistemas de protección**.

## Pruebas ejecutadas localmente

```bash
node --check app/src/main/assets/tv.js
python tests/test_animeav1_ui.py
javac -d build/qualitytest app/src/main/java/com/tokilite/tv/VideoQualityLabel.java tests/VideoQualityLabelTest.java
java -cp build/qualitytest com.tokilite.tv.VideoQualityLabelTest
```

Estas pruebas utilizan datos simulados del catálogo, comprueban rutas, paginación, filtros y el indicador de resolución. **No equivalen a probar una APK ni un stream real.**

## Compilación

Sube la raíz del proyecto a un repositorio GitHub con GitHub Actions habilitadas. Ejecuta `Build Toki Lite Fénix TV (APK)` desde *Actions* para obtener el artefacto `app-debug.apk`, o abre el proyecto con Android Studio y compila `:app:assembleDebug`. La firma de depuración puede ser diferente de la que usaban las betas anteriores; una actualización directa podría no instalarse.
