from pathlib import Path
from playwright.sync_api import sync_playwright
SCRIPT=(Path(__file__).resolve().parents[1] / 'app/src/main/assets/tv.js').read_text(encoding='utf-8')
HOME='''<html><body><h2>Top 10 de la semana</h2><section><a href="/anime/naruto"><img src="https://img.tokianime.tv/naruto.jpg" alt="Naruto">Naruto</a><a href="/anime/black-clover"><img src="https://img.tokianime.tv/black.jpg" alt="Black Clover">Black Clover</a></section><h2>Episodios recientes</h2><div><a href="/watch/naruto/1">Ep 1 Naruto</a></div></body></html>'''
DETAIL='''<html><body><h1>Naruto</h1><h2>Episodios</h2><section><a href="/watch/naruto/1">E1 Intro</a><a href="/watch/naruto/2">E2 Viaje</a></section></body></html>'''
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':720})
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content('<!doctype html><html><body style="margin:0;background:#080a0f"></body></html>')
    page.evaluate('''([home, detail])=>{
        window.TokiNative={calls:[],requestEpisode(url){this.calls.push(url)},cancelResolve(){this.calls.push('cancel')}};
        window.fetch=async url=>({ok:true,text:async()=>url.includes('/anime/')?detail:home});
    }''',[HOME,DETAIL])
    page.evaluate(SCRIPT)
    page.wait_for_timeout(400)
    assert page.locator('#tftv').count()==1
    page.locator('[data-series="https://tokianime.tv/anime/naruto"]').first.click()
    page.wait_for_timeout(400)
    assert page.locator('.episode-row').count()==2
    page.locator('.episode-row').first.click()
    assert page.locator('#tf-direct-player').count()==1
    calls=page.evaluate('window.TokiNative.calls')
    assert calls==['https://tokianime.tv/watch/naruto/1'], calls
    page.evaluate('window.__tokiTVPlayerError("Fuente externa no disponible")')
    assert 'Fuente externa no disponible' in page.locator('#tf-direct-player').inner_text()
    page.keyboard.press('Escape')
    assert page.locator('#tf-direct-player').count()==0
    assert 'cancel' in page.evaluate('window.TokiNative.calls')
    # Regression: native Activity must clear the pending loading modal
    # when a media URL has been resolved, then restore without trapping focus.
    page.locator('.episode-row').first.click()
    assert page.locator('#tf-direct-player').count() == 1
    page.evaluate('window.__tokiTVPlayerOpened()')
    assert page.locator('#tf-direct-player').count() == 0
    page.evaluate('window.__tokiTVPlayerReturned()')
    assert page.locator('#tf-direct-player').count() == 0
    assert not errors, errors
    print('PASSED: home, episodes, bridge, errors, remote back, player-return overlay, JS exceptions=0')
    browser.close()
