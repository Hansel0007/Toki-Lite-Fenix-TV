package com.tokilite.tv;
public final class OpaqueMediaInspectorTest {
    private static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    public static void main(String[] args) {
        byte[] mp4 = new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'};
        byte[] webm = new byte[]{0x1a,0x45,(byte)0xdf,(byte)0xa3};
        check("video/mp4".equals(OpaqueMediaInspector.classify("application/octet-stream", mp4)), "MP4 magic");
        check("video/webm".equals(OpaqueMediaInspector.classify(null,webm)), "WebM magic");
        check("application/x-mpegURL".equals(OpaqueMediaInspector.classify(null,"#EXTM3U\n#EXT-X".getBytes())), "HLS");
        check("application/dash+xml".equals(OpaqueMediaInspector.classify(null,"<?xml version='1'?><MPD".getBytes())), "DASH");
        check(OpaqueMediaInspector.classify("application/octet-stream", new byte[]{1,2,3,4})==null, "arbitrary binary rejected");
        check(OpaqueMediaInspector.classify("text/html", "<html>".getBytes())==null, "HTML rejected");
        check(TokiSourceParser.isOpaqueMediaCandidate("https://media.example.net/path/uuid.bin?x=a"), "bin candidate with query");
        check(!TokiSourceParser.isOpaqueMediaCandidate("http://media.example.net/path/uuid.bin"), "reject insecure");
        check(TokiSourceParser.findOpaqueMediaCandidates("<video src='https://cdn.example/a.bin'></video>","https://tokianime.tv/watch/bleach/301").size()==1, "explicit video attr");
        check(TokiSourceParser.findDirectMedia("<video src='https://cdn.example/a.bin'></video>","https://tokianime.tv/watch/bleach/301").isEmpty(), "unverified bin not treated as direct media");
        System.out.println("OK: opaque media classification, rejection, candidate detection");
    }
}
