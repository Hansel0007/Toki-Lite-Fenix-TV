from pathlib import Path
from playwright.sync_api import sync_playwright

base=Path(__file__).resolve().parents[1]
script=(base/'app/src/main/assets/tv.js').read_text()
HOME='''<!doctype html><html><body><h2>Recientemente Agregados</h2><section>
<a href="/media/bleach"><img src="https://cdn.animeav1.com/bleach.webp" alt="Portada de Bleach"/>Ver Bleach</a>
<a href="/media/naruto"><img src="https://cdn.animeav1.com/naruto.webp" alt="Portada de Naruto"/>Ver Naruto</a>
</section><h2>Episodios</h2><section><h3>Recientemente Actualizado</h3>
<a href="/media/bleach/301"><img src="https://cdn.animeav1.com/e301.webp" alt="backdrop"/>Ver Bleach 301</a></section></body></html>'''
CATALOG='''<html><body><h1>Catalogo de Animes</h1>
<a href="/media/one-piece"><img src="https://cdn.animeav1.com/op.webp" alt="Portada de One Piece">Ver One Piece</a>
<a href="/media/kaoru-hana-wa-rin-to-saku"><img src="https://cdn.animeav1.com/kaoru.webp" alt="Portada de Kaoru Hana wa Rin to Saku">Ver Kaoru</a>
</body></html>'''
CATALOG_2='''<html><body><a href="/media/dr-stone"><img alt="Portada de Dr. STONE" src="https://cdn.animeav1.com/drstone.webp"/>Ver Dr. STONE</a></body></html>'''
DETAIL='''<html><body><h1>Bleach</h1><img alt="Bleach Backdrop" src="https://cdn.animeav1.com/bleach-bg.webp"/>
<p>Ichigo Kurosaki descubre su destino como shinigami cuando una fuerza sobrenatural lo lleva a proteger el mundo de los vivos y el mundo de las almas.</p>
<h2>Episodios</h2><section>
<a href="/media/bleach/1"><img src="https://cdn.animeav1.com/e1.webp"/>Episodio 1</a>
<a href="/media/bleach/2"><img src="https://cdn.animeav1.com/e2.webp"/>Episodio 2</a>
</section><h2>Relacionados</h2><section>
<a href="/media/naruto/3">Episodio 3 Naruto</a><a href="/media/naruto-2nd-season">Temporada 2 Naruto</a></section></body></html>'''
GENRE='''<html><body><a href="/media/bleach"><img src="https://cdn.animeav1.com/bleach.webp" alt="Portada de Bleach"/></a></body></html>'''
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'],headless=True)
    page=browser.new_page(viewport={'width':1280,'height':720})
    errors=[]
    page.on('pageerror',lambda error: errors.append(str(error)))
    page.set_content('<html><head></head><body></body></html>')
    page.evaluate('''([HOME, CAT, CAT2, DETAIL, GENRE])=>{
      window.TokiNative={calls:[],requestEpisode(url){this.calls.push(url)},cancelResolve(){}};
      window.mockURLs=[];
      window.fetch=async function(url){
        url=String(url);window.mockURLs.push(url);
        let html=url.includes('/media/bleach')?DETAIL:
          url.includes('genre=accion')?GENRE:
          url.includes('page=2')?CAT2:
          url.includes('/catalogo')?CAT:HOME;
        return {ok:true,status:200,text:async()=>html};
      };
    }''',[HOME,CATALOG,CATALOG_2,DETAIL,GENRE])
    page.evaluate(script)
    page.wait_for_timeout(500)
    assert page.locator('#tftv').count()==1
    assert page.locator('[data-series="https://animeav1.com/media/bleach"]').count()>=1
    assert page.locator('.nav').count()==7
    page.locator('[data-nav="explore"]').click()
    page.locator('[data-genre="todos"]').click()
    assert page.locator('[data-series="https://animeav1.com/media/one-piece"]').count()>=1
    page.locator('[data-next]').click()
    page.wait_for_timeout(300)
    assert 'https://animeav1.com/catalogo?page=2' in page.evaluate('window.mockURLs')
    assert page.locator('[data-series="https://animeav1.com/media/dr-stone"]').count()>=1
    page.locator('[data-genre="accion"]').click()
    page.wait_for_timeout(300)
    assert page.locator('[data-series="https://animeav1.com/media/bleach"]').count()>=1
    page.locator('[data-nav="home"]').click()
    page.locator('[data-series="https://animeav1.com/media/bleach"]').first.click()
    page.wait_for_timeout(350)
    assert page.locator('.season').count()==1
    assert page.locator('.episode-row').count()==2
    page.locator('.episode-row').first.click()
    assert page.evaluate('window.TokiNative.calls')==['https://animeav1.com/media/bleach/1']
    page.evaluate('window.__tokiTVPlayerError("Fuente no comprobada")')
    assert 'Fuente no comprobada' in page.locator('#tf-direct-player').inner_text()
    assert not errors, errors
    print('PASSED AV1: public catalog, page 2 pagination, genre, correct series episodes, no false seasons, native player bridge')
    browser.close()
