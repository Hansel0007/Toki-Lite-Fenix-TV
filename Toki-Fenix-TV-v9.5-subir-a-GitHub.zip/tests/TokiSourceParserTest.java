package com.tokilite.tv;
import java.util.List;

public class TokiSourceParserTest {
  static void assertEqual(Object actual, Object expected) {
    if (!actual.equals(expected)) throw new AssertionError("Actual="+actual+" expected="+expected);
  }
  public static void main(String[] args) {
    String episode = "https://tokianime.tv/watch/demo/1";
    String html = "<video controls src='/media/ep1.mp4'></video>"+
      "<script>window.state={\"hls\":\"https:\\\\/\\\\/cdn.example.net\\\\/playlist.m3u8?token=abc\\\\u0026q=1\"};</script>"+
      "<iframe src='https://video.example.org/embed/abc'></iframe>"+
      "<source src='https://cdn.example.net/file.webm'>"+
      "<div data-file='https://cdn.example.net/hd.mpd'></div>";
    List<String> media = TokiSourceParser.findDirectMedia(html, episode);
    if(media.size()!=4) throw new AssertionError("Expected four: "+media);
    assertEqual(media.get(0), "https://tokianime.tv/media/ep1.mp4");
    if(!media.contains("https://cdn.example.net/playlist.m3u8?token=abc&q=1"))
      throw new AssertionError("Escaped HLS not handled: "+media);
    assertEqual(TokiSourceParser.findEmbedPages(html,episode).get(0), "https://video.example.org/embed/abc");
    if(TokiSourceParser.isDirectMediaUrl("https://video.example.org/embed/abc"))
      throw new AssertionError("Embed must not play as media");
    if(TokiSourceParser.isDirectMediaUrl("http://localhost/media.m3u8"))
      throw new AssertionError("Non HTTPS should be rejected");
    if(TokiSourceParser.normalize("javascript:alert(1)",episode)!=null)
      throw new AssertionError("Script URL should be rejected");
    List<String> htmlOnly = TokiSourceParser.findDirectMedia(
        "<h2>Temporada 1</h2><iframe src=\"https://player.example.org/e/efg\"></iframe>", episode);
    if (!htmlOnly.isEmpty()) throw new AssertionError("HTML player is NOT a media URL");
    if (TokiSourceParser.findEmbedPages("<iframe src=\"https://player.example.org/e/efg\"></iframe>", episode).size()!=1)
      throw new AssertionError("Missing embed metadata");
    System.out.println("OK: direct MP4/HLS/DASH/WebM, escaped JS, iframe separation, unsupported HTML and URL checks");
  }
}
