#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/parser-test
javac -d build/parser-test app/src/main/java/com/tokilite/tv/TokiSourceParser.java tests/TokiSourceParserTest.java \
  app/src/main/java/com/tokilite/tv/OpaqueMediaInspector.java tests/OpaqueMediaInspectorTest.java
java -cp build/parser-test com.tokilite.tv.TokiSourceParserTest

java -cp build/parser-test com.tokilite.tv.OpaqueMediaInspectorTest
