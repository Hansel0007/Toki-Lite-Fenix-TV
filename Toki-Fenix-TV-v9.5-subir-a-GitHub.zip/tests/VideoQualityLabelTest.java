package com.tokilite.tv;
public class VideoQualityLabelTest {
    private static void expect(int h, String label) {
        String actual = VideoQualityLabel.fromVideoHeight(h);
        if (!label.equals(actual)) throw new AssertionError(h + ": " + actual);
    }
    public static void main(String[] args) {
        expect(0, "Calidad: —");
        expect(480, "Vídeo: 480p · SD");
        expect(720, "Vídeo: 720p · HD");
        expect(1080, "Vídeo: 1080p · Full HD");
        expect(2160, "Vídeo: 2160p · 4K UHD");
        System.out.println("PASSED: Media3 resolution labels are based on actual height");
    }
}
