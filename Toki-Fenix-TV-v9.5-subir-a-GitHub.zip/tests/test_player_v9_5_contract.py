"""Static contract checks for the v9.5 native player (NOT Android runtime tests)."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
player=(root/'app/src/main/java/com/tokilite/tv/NativePlayerActivity.java').read_text()
main=(root/'app/src/main/java/com/tokilite/tv/MainActivity.java').read_text()
resolver=(root/'app/src/main/java/com/tokilite/tv/TokiStreamResolver.java').read_text()
js=(root/'app/src/main/assets/tv.js').read_text()
assert 'playerView.setUseController(false)' in player
assert 'showAudioMenu' in player and 'showSubtitleMenu' in player and 'showServerMenu' in player
assert '⇄  Cambiar' in player and 'Audio' in player and 'Subtítulos' in player
assert 'VideoQualityLabel.fromVideoHeight' in player
assert 'getCurrentTracks' in player and 'TrackSelectionOverride' in player
assert 'HIDE_MS = 4200' in player and 'setControlsVisible(false)' in player
assert 'sources.size() < 2' in player and 'Solo hay un servidor multimedia verificado' in player
assert 'sourceUrls' in main and 'sourceUrls' in player
assert 'sourceReferers' in main and 'sourceReferers' in player
assert 'foundWithReferer(url, episode, urls.subList(1' in resolver
assert 'window.TokiNative.requestEpisode(item.url,' in js
assert 'setMediaItem(item.build())' in player and 'player.prepare()' in player
print('PASS: native TV controls, tracks, quality, focus, server alternatives, no fabricated server choices')
