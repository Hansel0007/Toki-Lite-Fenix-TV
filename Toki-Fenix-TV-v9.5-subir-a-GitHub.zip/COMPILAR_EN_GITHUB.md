# Generar APK de Toki Lite Fénix TV con GitHub Actions

## Proyecto
Código v9.5 para Android TV / Amazon Fire TV Stick 4K Max 2.ª generación.
La interfaz Fénix está implementada, pero el acceso a los vídeos de AnimeAV1 aún no está validado en un Fire Stick real.
La compilación correcta **NO** garantiza reproducción.

## Procedimiento (sin instalar Android Studio)

1. En GitHub, crea un repositorio **nuevo**, por ejemplo `toki-lite-fenix-tv` (puede ser privado). No lo mezcles con otros proyectos.
2. Descomprime este ZIP. Sube el **contenido** de la carpeta `Toki-Lite-Fenix-TV-GitHub-Actions` a la raíz del nuevo repositorio, incluida la carpeta oculta `.github`. Haz commit a `main`.
   - Para subir carpetas y archivos grandes, Git de escritorio o `git push` es lo más fiable.
   - Si subes desde la web y los archivos ocultos no aparecen, arrastra expresamente `.github/workflows/android-apk.yml`.
3. Abre la pestaña **Actions** del repositorio y selecciona **Compilar Toki Lite Fénix TV APK**. Ejecuta **Run workflow** si no se inició con el push.
4. Cuando termine con marca verde, abre el run y descarga el artefacto **Toki-Lite-Fenix-TV-v9_5-APK**.
5. Extrae el archivo descargado y copia `app-debug.apk` al Fire Stick para instalarlo.

## Validaciones en CI
- JavaScript `node --check`.
- Pruebas Java de extracción/inspección de fuentes.
- Pruebas Python de UI y controles.
- Compilación Android Gradle Plugin 8.9.2 + Gradle 8.12 + Media3 1.11.1.
- Verificación de firma mediante `apksigner` y hash SHA-256.

## Aclaración sobre la firma
La APK de depuración se firma automáticamente con la clave de GitHub Actions. Puede no coincidir con las versiones v1–v7 firmadas con otro certificado. Android exigirá desinstalar la versión anterior si la firma es distinta; eso elimina la sesión y los datos locales. Para actualizaciones futuras de la misma aplicación conviene implementar una firma de publicación propia y estable.

## Reproductor y fuentes
El uso de Media3 habilita MP4, HLS y DASH, pero la reproducción depende de que exista un enlace multimedia válido y permitido. El adaptador actual es experimental y puede no obtener streams de los servidores de AnimeAV1; no suplanta autentificaciones ni elimina DRM.
