# Toki Lite Fénix TV v9.2 — investigación técnica e implementación

## Lo que hace UKIKU (verificado en su código público)

1. `JsExtractor.kt` recupera el HTML de la página de un episodio y localiza un array JavaScript con un patrón `data: [`.
2. Ejecuta análisis de los datos publicados para extraer `embeds` y `downloads`; no da por hecho que un `iframe` es un archivo multimedia.
3. `TVServersFactory.kt` separa alternativas de servidor y audio, llama a resolutores por proveedor y recibe un objeto `Option` con URL y cabeceras.
4. `TVPlayer` usa el vídeo proporcionado por el resolutor. Las opciones identificadas como `(WEB)` continúan dependiendo de un navegador.
5. `BypassUtil.kt` incluye un flujo para gestionar páginas con protección anti-bot de AnimeAV1. Eso no implica que la página de Toki use el mismo esquema.

Repositorio: https://github.com/jordyamc/UKIKU (MIT; revisar la licencia antes de copiar fragmentos del proyecto).
Archivos relevantes:
- https://github.com/jordyamc/UKIKU/blob/master/app/src/main/java/knf/kuma/commons/JsExtractor.kt
- https://github.com/jordyamc/UKIKU/blob/master/app/src/main/java/knf/kuma/tv/TVServersFactory.kt
- https://github.com/jordyamc/UKIKU/blob/master/app/src/main/java/knf/kuma/videoservers/ServersFactory.kt
- https://github.com/jordyamc/UKIKU/blob/master/app/src/main/java/knf/kuma/commons/BypassUtil.kt

## Hechos de Toki confirmados

- Las fichas públicas y episodios usan rutas como `/anime/dragon-ball-z` y `/watch/dragon-ball-z/203`.
- Las fichas proporcionan título, sinopsis, episodios, portadas y orden de visionado.
- La página de episodio puede mostrar una temporada dentro de una *franquicia*, que no corresponde necesariamente a una segunda temporada del mismo título. No mezclar los capítulos de distintos slugs.
- La vista de página consultada no proporciona una URL MP4/HLS/DASH directamente verificable. Es posible que se publique dinámicamente mediante scripts o servicios externos.

Sitio: https://tokianime.tv/watch/dragon-ball-z/203

## Cambios de código de v9.2

- **TokiSourceParser.java (nuevo)**: lectura segura y comprobable de enlaces multimedia declarados en HTML/atributos `<video>`, `<source>`, `data-file`, variables JavaScript sencillas y strings escapados. Normaliza URLs HTTPS y separa `iframe` de stream directo. No interpreta HTML como vídeo.
- **TokiStreamResolver.java**: inicia en paralelo un GET limitado del HTML del episodio y la detección dinámica ya existente. Si la página declara directamente un enlace multimedia, lo entrega a Media3; si solo aparece un `iframe`, informa del límite en vez de quedarse cargando indefinidamente.
- **NativePlayerActivity.java**: conserva el `Referer` HTTPS del recurso observado en la solicitud original (no fuerza incorrectamente el `Referer` de Toki para todos los proveedores).
- **tests/TokiSourceParserTest.java**: casos positivos de MP4, WebM, HLS, DASH y casos negativos de iframes, JavaScript URLs y HTTP.
- **app/build.gradle**: número de versión de prueba actualizado a 10.

## Lo que NO se ha verificado

- No se ha podido obtener ni reproducir un stream real desde Toki en esta sesión. Ninguna prueba sintética demuestra que los servidores actuales de Toki expongan fuentes compatibles.
- No se han saltado DRM, captchas, medidas anti-bot, restricciones de sesión, pagos ni permisos de terceros.
- No hay APK nuevo compilado y probado: el Android SDK y las dependencias de Media3 no están disponibles en el entorno de ejecución.
- La URL de vídeo podría requerir tokens de corta vida, cabeceras adicionales o reproductor web obligatorio. En esos casos la app informa fallo.

## Pruebas

Ejecutar `sh tests/run-parser-tests.sh` (necesita `javac`).
Para compilar el proyecto completo, usar Android Studio o `.github/workflows/android-apk.yml` en un repositorio propio con Android SDK, Gradle y acceso a las dependencias.

## Próximo diagnóstico sobre el dispositivo

En la aplicación instalada en Fire Stick, obtener de forma autorizada el log del reproductor y, si se puede, una descripción de las solicitudes multimedia y tipo de contenido (sin compartir cookies, tokens ni credenciales). Identificar qué servidor entrega realmente el vídeo y si permite un cliente externo. Solo entonces se puede escribir y validar un resolutor específico, al estilo de los adaptadores por proveedor de UKIKU.
